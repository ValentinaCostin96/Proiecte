<?php session_start(); 
$flag = 0;
$Users = file_get_contents("./res/users.txt");
$array = json_decode($Users,true );
for ($x = 0; $x < count($array); $x++)
{	
	if ($_POST['user'] == $array[$x]['Nume'] && $_POST['password'] == $array[$x]['Password'])
	{
		$_SESSION['user'] = $_POST['user'];
		$flag = 1;
	}
}

if ($flag == 0)
{		
	$_SESSION['eroare'] = "Eroare nume utilizator sau/si parola invalide!";	
}

if ($flag != 0)
{
	$Cos = file_get_contents("./res/cos.txt");
	$CosArray = json_decode($Cos, true);
	for ($x = 0; $x < count($CosArray); $x++)
	{
		if ($_SESSION['user'] == $CosArray[$x]['Nume'])
		{
			$_SESSION['cos'] = array();
			$_SESSION['cos'] = $CosArray[$x]['Cos'];
		}
	}
}

header("Location: ".$_SERVER["HTTP_REFERER"]);	
?>
