function myFunction() { /*creeaza un buton*/
    var btn = document.createElement("BUTTON");
    btn.innerHTML = "CLICK ME";
    document.body.appendChild(btn);
}

function changeImage() {
    var image = document.getElementById('myImage');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg"; 
    }
    else {
        image.src = "img/desk2.jpg";

    }

    var elem = document.getElementById("myImage");
    if (elem.value=="BOOK") elem.value = "FREE";
    else elem.value = "BOOK";
}

function changeImage1() {
    var image = document.getElementById('myImage1');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage2() {
    var image = document.getElementById('myImage2');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage3() {
    var image = document.getElementById('myImage3');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage4() {
    var image = document.getElementById('myImage4');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage5() {
    var image = document.getElementById('myImage5');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage6() {
    var image = document.getElementById('myImage6');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage7() {
    var image = document.getElementById('myImage7');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage8() {
    var image = document.getElementById('myImage8');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage9() {
    var image = document.getElementById('myImage9');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage10() {
    var image = document.getElementById('myImage10');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function changeImage11() {
    var image = document.getElementById('myImage11');
    if (image.src.match("img/desk2.jpg")) {
        image.src = "img/desk1.jpg";
    }
    else {
        image.src = "img/desk2.jpg";
    }
}
function change1() 
{
    var elem = document.getElementById("b1");  
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change2() 
{  
    var elem = document.getElementById("b2");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change3() 
{ 
    var elem = document.getElementById("b3");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change4() 
{ 
    var elem = document.getElementById("b4");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change5() 
{
    var elem = document.getElementById("b5");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change6() 
{
    var elem = document.getElementById("b6");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change7() 
{  
    var elem = document.getElementById("b7");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change8() 
{  
    var elem = document.getElementById("b8");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change9() 
{  
    var elem = document.getElementById("b9");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}

function change10() 
{  
    var elem = document.getElementById("b10");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}
function change11() 
{
    var elem = document.getElementById("b11");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}

function change12() 
{
    var elem = document.getElementById("b12");
    var elem2 = document.getElementById("free_book");
    if (elem.value=="BOOK") {
        elem.value = "FREE";
        elem2.value = "FREE TABLE"
    }
    else
    {
         elem.value = "BOOK";
         elem2.value = "BOOK TABLE"
    }
}

function loadDoc(pagina) {
	var xmlhttp;

	if (window.XMLHttpRequest) {
		xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				document.getElementById("continut").innerHTML = xmlhttp.responseText;
	
			}
		}
	}

	xmlhttp.open("GET", pagina, true);
	xmlhttp.send();
}
/*modal - if the user click outside the model. Modal will close*/
var modal = document.getElementById('modal-wrapper');
window.onclick = function(event){
    if(event.target == modal)
    {
       this.modal.style.display = "none"; 
    }
}

/* cred ca pt fiecare masa treb sa fie un modal separat - e ineficient, dar asta e */