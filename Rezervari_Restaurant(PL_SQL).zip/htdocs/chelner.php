<?php
	session_start();
?>
<html lang="ro">

<head>
	<title>HelpChelner</title>
	<meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="css/stil.css" />
    <script src="js/myscripts.js"></script>
    <script src="js/script.js"></script>
</head>
<body style="background-color:#e6e6ff">
    
    <button class="myButton" type="button" onclick="loadDoc('logout.php')" style="float:right"><a href="login.php" 
                        onclick="loadDoc('login.php')" style = "text-decoration:none;">LOG OUT</a></button>
                        
    <p style="text-align:center; font-size:40px; margin-top:5px "><b>Availability of tabels in the restaurant</b></p>
    <div id="modal-wrapper" class="modal" >
        <form class="modal-content animate" action="/action_page.php">
            <div class="imgcontainer">
                <span onclick="document.getElementById('modal-wrapper').style.display='none'" 
                class="close" title="Close PopUp";> &times; </span>
                <h1>Your table</h1>
            </div>

            <div class="container">
                <label style="font-size:20px; margin-left:17px;" ><b>Order drink:&nbsp;&nbsp;&nbsp;</b></label>
                <span>
                    <select id="drop" style="width:30%" required >
                        <option value="">Choose</option>
                        <option value="cola">Coca Cola</option>
                        <option value="Pepsi">Pepsi</option>
                        <option value="sprite">Sprite</option>
                        <option value="">Tea</option>
                        <option value="">Coffee</option>
                        <option value="">Hot chocolate</option>
                        <option value="water">Aqua Carpatica</option>
                        <option value="wine">Red wine></option>
                        <option value="wine2">White wine</option>
                        <option value="rachiu">Scented water</option>
                        <option value="champagne">Champagne</option>
                        <option value="">Beer</option>
                        <option value="">Cider</option>
                    </select>
                    &nbsp;&nbsp;
                    <label style="font-size:20px; margin-left:17px;" ><b>Price:</b></label>
                    <input type="text" style="width:10%; height:3%;" />
                    <label><b>lei</b></label>
                </span>
                <br /><br />
                <span>
                     <label style="font-size:20px; margin-left:17px;" ><b>How many?&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                     <input type="number" style="width:10%; height:3%;"/>&nbsp;&nbsp;&nbsp;
                     <button type="submit" id = "plus"><b>ADD</b></button> &nbsp;&nbsp;
                     
                </span>
                <br /><br />
                <span>
                    <label style="font-size:20px; margin-left:17px;" ><b>Rezervation name:</b></label>
                    <input type="text" style="width:50%; height:3%" />
                </span>
                <br />
                <span>
                    <label style="font-size:20px; margin-left:17px;" ><b>TOTAL:</b></label>
                    <input type="text" style="width:15%; height:3%" />
                </span>
                <br /><br />
                <div style="height:40%; width:90%; background-color:#f2f2f2; margin-left:5%">
                    <table style="width:99%; border-collapse: collapse; margin:0.5%; margin-top:10px;">
                        <tr>
                            <th>Product name</th>
                            <th>Price/prod</th>
                            <th>Nr. products</th>
                            <th>Remove</th>
                        </tr>
                        <tr class="t1">
                            <td>Jill</td>
                            <td>Smith</td>
                            <td>50</td>
                            <td><input type="checkbox" /></td>
                        </tr>
                        <tr class="t1">
                            <td>Eve</td>
                            <td>Jackson</td>
                            <td>94</td>
                            <td><input type="checkbox" /></td>
                        </tr>
                    </table>
                </div>
                <button id = "free_book"  onclick="changeImage();change1()" style="width:90%" type="submit">BOOK TABLE</button>
           </div>
        </form>/
    </div>


    <table style="border-style:hidden;">
        <tr class= "desk">
            <td class="borduraT">
                <img id= "myImage" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">1->(4 seats)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'"  value="BOOK" id = "b1" />
            </td>
            <td class="borduraT">
                <img id= "myImage1" src="img/desk2.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">2->(4 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="FREE" id = "b2"/>
            </td>
            <td class="borduraT">
                <img id= "myImage2" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">3->(4 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b3" />
            </td>
            <td class="borduraT">
                <img id= "myImage3" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">4 ->(4 seats)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b4" />
            </td>
        </tr>

        <tr class= "desk">
            <td class="borduraT">
                <img id= "myImage4" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">5->(4 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b5" />
            </td>
            <td class="borduraT">
                <img id= "myImage5" src="img/desk2.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">6->(8 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="FREE" id = "b6"/>
            </td>
            <td class="borduraT">
                <img id= "myImage6" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">7->(8 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b7"/>
            </td>
            <td class="borduraT">
                <img id= "myImage7" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">8->(2 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b8"/>
            </td>
        </tr>

        <tr class= "desk">
            <td class="borduraT">
                <img id= "myImage8" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">9->(2 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b9"/>
            </td>
            <td class="borduraT">
                <img id= "myImage9" src="img/desk2.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">10->(2 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="FREE" id = "b10"/>
            </td>
            <td class="borduraT">
                <img id= "myImage10" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">11->(2 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button"onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b11"/>
            </td>
            <td class="borduraT">
                <img id= "myImage11" src="img/desk1.jpg" width="210px" height = "150px" alt="masa"/>
                <p style="text-align:center">12->(4 seats) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp; 
                <input type="button" onclick="document.getElementById('modal-wrapper').style.display='block'" value="BOOK" id = "b12"/>
            </td>
        </tr>
    </table>
</body>