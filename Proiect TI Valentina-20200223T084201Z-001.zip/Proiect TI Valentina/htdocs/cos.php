<?php session_start();?>


		<section>
		<?php
		if (!isset($_SESSION['user']))
		{	
			echo "<form id='FormaLogare' action = 'login.php' method = 'post'>
			<center><h2>Logare:</h2></center><br/>
			Nume: <input type = 'text' name='user'/><br/><br/>
			Parola: <input type = 'password' name = 'password'/><br/><br/>
			<input class='MenuElement' id='FormaLogareButon' type = 'submit' value = 'Logare'/>
			</form>";
			if (isset($_SESSION['eroare']))
			{
				echo"<center><h2>".$_SESSION['eroare']."</h2></center>";				
			}
		}
		else
		{
			echo "<div style='width:15%; float:left; display:block'><h2 id='MesajBunVenit'>Bun Venit, ".$_SESSION['user']."</h2>";
			echo "<form  action='logout.php'>
			<input class='MenuElement' type = 'submit' value='Delogare'/>
			</form><br/>
			</div>";
			echo "<br/><br/><center><h1 style='margin-right:300px'>Cosul meu</h1></center>"; 	
		}
		$produse = file_get_contents("./res/produse.txt");
		$array = json_decode($produse, true);
		echo "<div class='Specificatii' style='margin-top:100px;'><br/>";
		foreach ($_SESSION['cos'] as $x => $item)	
		{
			$id =  $_SESSION['cos'][$x];
			echo "<center>".$array[$id]['Denumire']."</center>";
			echo "<center>".$array[$id]['Pret']."</center>";
			echo "<center><form action='cumpara.php' method='get'>
			<input type = 'hidden' name='id' value = '".$id."'>
			<input class='MenuElement' type = 'submit' value='Cumpara produsul' style='width:280px'/>  <!--procura produsul-->
			</form></center>";
			echo "<br/><br/>";
		}
		echo "</div>";
		?>
		</section>
	
	</body>

</html>	

		