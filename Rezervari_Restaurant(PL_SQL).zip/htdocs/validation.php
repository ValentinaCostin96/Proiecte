<?php				/*logare*/
session_start();  

include "fisier_conexiune_db.php";
$name=$_POST['user'];
$pass=$_POST['password'];
$tip=$_POST['tip_user'];
$v_returnat=0;
$result2=oci_parse($conn," declare v_local number;
		begin
		v_local:=functie_log_in(:name,:pass,:tip);
		:v_returnat:=v_local;
		end;");
oci_bind_by_name($result2, ':name', $name);
oci_bind_by_name($result2, ':pass', $pass);
oci_bind_by_name($result2, ':tip', $tip);
oci_bind_by_name($result2, ':v_returnat', $v_returnat);
oci_execute($result2);
echo $v_returnat;
if($v_returnat==3)
{
	$_SESSION['user']=$name;
	if($tip=='admin')
	{
	header('location:admin.php');
	}elseif($tip=='chelner'){
		header('location:chelner.php');
	}else{
		header('location:client.php');
	}
}else{
	header('location:login.php');
}
oci_free_statement($result2);
oci_close($conn);
/*
mysqli_select_db($con,'userregistration');

$name=$_POST['user'];
$pass=$_POST['password'];

$s = " select * from users where name= '$name' && password = '$pass'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if($num == 1)
{
	$_SESSION['username']=$name;
	header('location:chelner.php');
}
else
{
	header('location:login.php');
}
*/
/* preluare date din baza de date
$result=oci_parse($conn,"select * from STOC");
oci_execute($result);
while(oci_fetch($result))
{
	echo oci_result($result,'NUME_PRODUS');
}
*/
?>