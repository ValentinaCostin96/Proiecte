//pentru partea de modal  register/ log in 
function loginRequest(){
	document.getElementById('mdl').style.display='block';
}
function registerRequest(){
	document.getElementById('register').style.display='block';
}
function loginRequestOff(){
	document.getElementById('mdl').style.display='none';
}
function registerRequestOff(){
	document.getElementById('register').style.display='none';
}

//pentru partea de modal  VIEW/BUY
function buy(){
	document.getElementById('mdl2').style.display='block';
}
function view(){
	document.getElementById('register2').style.display='block';
}
function buyRequestOff(){
	document.getElementById('mdl2').style.display='none';
}
function viewRequestOff(){
	document.getElementById('register2').style.display='none';
}

function myFunction() {
	  document.getElementById("myDropdown").classList.toggle("show");
	}
	window.onclick = function(event) {
	  if (!event.target.matches('.dropbtn')) {
	    var dropdowns = document.getElementsByClassName("dropdown-content");
	    var i;
	    for (i = 0; i < dropdowns.length; i++) {
	      var openDropdown = dropdowns[i];
	      if (openDropdown.classList.contains('show')) {
	        openDropdown.classList.remove('show');
	      }
	    }
	  }
	}
