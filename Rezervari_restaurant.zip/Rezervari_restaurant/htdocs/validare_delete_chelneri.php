<?php
session_start();
include "fisier_conexiune_db.php";
$id=$_POST['id_chelner'];



//$result1=oci_parse($conn,"delete from utilizator where id_user=:id and tip_user='chelner'");
$result1=oci_parse($conn,"begin   PACK_USERS.DEL_USERS(:id);
END;");
oci_bind_by_name($result1, ':id', $id);
oci_execute($result1);
echo $result1;
echo 'am ajuns aici';
header('location:chelneri.php');
oci_free_statement($result1);
oci_close($conn);

?>