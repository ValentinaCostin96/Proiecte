<?php
session_start();
include "fisier_conexiune_db.php";
$nume=$_POST['nume_client'];
$parola=$_POST['parola_client'];


//$result1=oci_parse($conn,"delete from utilizator where id_user=:id and tip_user='chelner'");
$result1=oci_parse($conn,"delete from utilizator where nume_user=:nume and pass_user=:pass and tip_user='client'");
oci_bind_by_name($result1, ':nume', $nume);
oci_bind_by_name($result1, ':pass', $parola);
oci_execute($result1);
echo $result1;
echo 'am ajuns aici';
header('location:login.php');
oci_free_statement($result1);
oci_close($conn);

?>