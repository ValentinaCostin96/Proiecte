<?php
		if (!isset($_SESSION['user']))
		{	
			echo "<form id='FormaLogare' action = 'login.php' method = 'post'>
			<center><h2>Logare:</h2></center><br/>
			Nume: <input type = 'text' name='user'/><br/><br/>
			Parola: <input type = 'password' name = 'password'/><br/><br/>
			<input class='MenuElement' id='FormaLogareButon' type = 'submit' value = 'Logare'/>
			</form>";
			if (isset($_SESSION['eroare']))
			{
				echo"<center><h2>".$_SESSION['eroare']."</h2></center>";				
			}
		}
		else
		{
			echo "<div id ='FormaLogare'><h2 id='MesajBunVenit'>Bun Venit, ".$_SESSION['user']."</h2>";
			echo "<form  action='logout.php'>
			<input class='MenuElement' type = 'submit' value='Delogare'/>
			</form><br/>";
			echo "<form  action='Portofel.php'>
			
			</form></div>";
			echo "<form action = 'cos.php'>
			<input  class= 'Cos' type = 'submit' value = 'Cosul meu'/>
			</form>";
		}
		?>

<section>	
		<div id = "Column">
			<ul id="content">	
                <li><a  href="Hanorac.php"> <img src="./femei/haine/f1.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Hanorac cu gluga cu imprimeu Rose</p>
				</a> </li>
				<br /><br /><br /><br /><br /><br /><br /><br />
				<li><a  href="Ie.php"> <img src="./femei/haine/f9.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Ie Traditionala Elizabeta 4 – Centenar </p>
				</a> </li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="Jacheta.php"> <img src="./femei/haine/f2.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Hanorac Baseball Alien cu broderie </p>
				</a> </li>
				<br /><br /><br /><br /><br /><br />
			</ul>
		</div>
		

        <div id = "Column">
			<ul id="content">
            <li><a  href="Pizza.php"> <img src="./femei/haine/f3.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Top Fullprint Pizza </p>
				</a> </li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="Bluza.php"> <img src="./femei/haine/f4.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Bluza </p>
				</a> </li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="Fusta.php"> <img src="./femei/haine/f5.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Fusta </p>
				</a> </li>
				<br /><br /><br /><br /><br /><br />
			</ul>
		</div>

        <div id = "Column">
			<ul id="content">
            <li><a  href="Palton.php"> <img src="./femei/haine/f6.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Geaca </p>
				</a> </li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="Rochie.php"> <img src="./femei/haine/f10.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Rochie Rosie</p>
				</a> </li>
				<br /><br /><br /><br /><br /><br />
			</ul>
		</div>
<!-- pentru imaginea de flip-flop -->
<div class="josright">
    <div class="flip-box">
    <div class="flip-box-inner">
        <div class="flip-box-front">
        <img class="sticky1" src="./imagini/jos.jpg" alt="Podium Shop" style="width:300px;height:200px">
        </div>
        <div class="flip-box-back">
        <h2>Podium Shop</h2>
        <p>Ați gasit ceea ce căutați?</p>
        </div>
    </div>
    </div>
</div>