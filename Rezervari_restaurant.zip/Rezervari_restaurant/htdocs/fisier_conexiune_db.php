<?php 
    $conn=oci_connect("proiect","1234","localhost/XE");
    If (!$conn)
        echo 'Failed to connect to Oracle';
    else
        echo '';
?>