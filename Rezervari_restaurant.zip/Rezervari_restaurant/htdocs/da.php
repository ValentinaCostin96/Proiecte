<html lang="ro">
<head>
	<title>Biblioteca Valentinei</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/stil.css" />
</head>
<body>
    <h1> TE-AI INREGISTRAT CU SUCCES! Felicitari!</h1>
    <br />
    <br />
    <a  href="login.php" onclick="loadDoc('logout.php')"  style="text-collor:red ">go back</a>
</body>