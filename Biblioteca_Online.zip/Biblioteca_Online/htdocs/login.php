<!DOCTYPE html>

<html lang="ro">
<head>
	<title>Biblioteca Valentinei</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/stil.css" />
</head>

<body  style="background-image:url('img/book.jpg') ">
    <h1 text-aling="center" style="margin:50px; padding-left:70px"><img src="img/book.jpg" width="40px" height="30px" />&nbsp;Biblioteca Valentinei</h1>
    <br />
    <br />

    <div class="container">
        <div class="login-box">
        <div class="row">
            <div class="col-md-6 login-left">
                <h2>Login Here</h2>
                <form action="validation.php" method ="post">
                    <div class="form-group">
                        <label>Username</label><br/><br />  
                        <input type="text" name="user" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <br />
                        <label>Password</label><br/><br />
                        <input type="password" name="password" class = "form-cotrol" required/>
                    </div>
                    <br/><br/>
                    <button type="submit" class="btn btn-primary">Login </button>
                </form>
            </div>
            <br />
            <div class="col-md-6 login-right">
                <h2>Register Here</h2>
                <form action="registration.php" method ="post">
                    <div class="form-group">
                        <label>Username</label><br/><br />
                        <input type="text" name="user" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <br />
                        <label>Password</label><br/><br />
                        <input type="password" name="password" class = "form-cotrol" required/>
                    </div>
                    <br/><br/>
                    <button type="submit" class="btn btn-primary">Register </button>
                </form>
            </div>
        </div>
           
     </div>
     </div>



</body>