<?php
session_start();
include "fisier_conexiune_db.php";
$name=$_POST['nume_produs'];
/*echo $name."<br/>";*/
$price=$_POST['pret_produs'];
/*echo $pass."<br/>";*/
$quantity=$_POST['cantitate_produs'];

//$result=oci_parse($conn,"insert into stoc values(NULL,:name,:price,:quantity)");
$result=oci_parse($conn,"BEGIN PACK_STOC.ADD_STOC(:name,:price,:quantity); end;");
oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':price', $price);
oci_bind_by_name($result, ':quantity', $quantity);
oci_execute($result);
echo 'am ajuns aici';
header('location:stoc.php');
oci_free_statement($result);
oci_close($conn);

?>