<html>
<head><title>Oracle demo</title></head>
<body>
    <?php 
    $conn=oci_connect("psbd","1234","localhost/XE");
    If (!$conn)
        echo 'Failed to connect to Oracle';
    else
        echo 'Succesfully connected with Oracle DB';
	//oci_select_db($conn,'emp');
	//$s="select * from emp";
	//$result=oci_query($conn,$s);
	$result=oci_parse($conn,"select * from STOC2");
	oci_execute($result);
	while($row=oci_fetch_array($result))
	{
		echo $row['PRET'];
		echo " ";
	}
	?>
	
<?php	
oci_close($conn);
?>
 
</body>
</html>