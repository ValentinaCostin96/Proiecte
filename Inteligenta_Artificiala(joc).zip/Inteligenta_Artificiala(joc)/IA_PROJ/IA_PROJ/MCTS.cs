﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IA_PROJ
{
    class MCTS
    {
        public int[,] tabla = new int[9, 9];

        Dictionary<string, string> mapper = new Dictionary<string, string>
        {
            { "22", "30"},
            { "52", "03"},
            { "25", "60"},
            { "82", "33"},
            { "55", "06"},
            { "28", "63"},
            { "85", "36"},
            { "58", "66"}
        };
        //returneaza nodul cu np=0 sau null in cazul in care nu s-a gasit nici un nod
        public Nod Selection(Nod node)
        {
            foreach (Nod nod in node.child_list)
            {
                if (nod.np == 0)
                {
                    return nod;
                }
            }
            return null;
        }


        double calculS(Nod n)
        {
            double C = Math.Sqrt(2);
            int D = 5000;
            int valoare_castig = 1;
            int x_b = valoare_castig / n.np;//valoarea jocului = simulari rezultate cu o victorie / nr de simulari
            double a = Math.Log(n.np) / n.ni;
            double b = (n.vi - n.ni * (x_b ^ 2) + D) / n.ni;
            double Suma = x_b + C * Math.Sqrt(a) + Math.Sqrt(b);
            //t(n) = np -> de cate ori a fost vizitat nodul n
            //t(ni) = ni -> de cate ori a fost vizitat copilul
            //x^2 = vi -> suma rezultatelor din copil
            //D = constanta adaugata pentru a se asigura ca nodurile care au fost vizitate mai rar sunt nesigure
            return Suma;
        }
        public Nod Expansion(Nod node)
        {
            int i = node.pozitie.Item1;
            int j = node.pozitie.Item2;
            int rest_i = i % 3, rest_j = j % 3, floor_j = j / 3;
            node.np++;
            do
            {
                if (rest_i == 2 && rest_j == 2)
                {
                    string key = i.ToString() + j.ToString();
                    if (mapper.ContainsKey(key))
                    {
                        string[] value = mapper[key].Split();
                        i = Int32.Parse(value[0]);
                        j = Int32.Parse(value[1]);
                    }
                }
                else if (rest_j == 2)
                {
                    i++;
                    j = floor_j * 3;
                }
                else
                    j++;
            } while (node.tabla[i, j] != 0);
            for (int k = 1; k < 10; k++)
                node.child_list[k - 1].tabla[i, j] = k;
            return node;
        }
        public void Backpropagation(Nod node)
        {
            List<Nod> head = node.child_list;
            double val;
            foreach (Nod x in head)
            {
                node.ni += x.np;
            }
            val = calculS(node);
            node.nod_parinte.S = val;
        }
    
    public bool validareLinie(Tuple<int, int> pos, int val)
        {

            int l;
            l = pos.Item1;
            bool exista;
            exista = true;
            for (int j = 0; j < 9; j++)
            {
                if (tabla[l, pos.Item2] == val)
                { //nok, exista deja nr asta pe linie
                    exista = true;
                }
                else
                { //nu exista nr, deci il putem scrie
                    exista = false;
                }
            }
            return exista;
        }

        //metoda ce face verificarea pe coloana
        public bool validareColoana(Tuple<int, int> pos, int val)
        { //pot sa trimit doar j din tuplu
            int c;
            c = pos.Item2;
            bool exista = true;
            for (int i = 0; i < 9; i++)
            {
                if (tabla[pos.Item1, c] == val)
                { //nok
                    exista = true;
                }
                else
                {
                    exista = false;
                }
            }
            return exista;
        }
        public bool ExistaInVector(int[] v, int val)
        {
            bool exista = false;
            foreach (var i in v)
            {
                if (i == val)
                {
                    exista = true;
                }
                else
                {
                    exista = false;
                }
            }
            return exista;
        }

        //metoda de validare pe chenar
        public bool validareChenar(Tuple<int, int> pos, int val)
        {
            bool exista = true;

            int[] v = new int[3] { 1, 4, 7 };
            bool exista1, exista2;
            exista1 = ExistaInVector(v, pos.Item1);
            exista2 = ExistaInVector(v, pos.Item2);

            if (exista1 == true && exista2 == true)
            { // sunt in centru chenarului
                int l, c;
                for (l = pos.Item1 - 1; l <= pos.Item1 + 1; l++)
                {
                    for (c = pos.Item2 - 1; c <= pos.Item2 + 1; c++)
                    {
                        if (tabla[l, c] == val)
                        { //nok
                            exista = true;
                        }
                        else
                        {
                            exista = false;
                        }
                    }
                }
            }
            else
            { //linii margina
                if (pos.Item1 % 3 == 0)
                { //margina de sus
                    int l, c;
                    for (l = pos.Item1; l <= pos.Item1 + 2; l++)
                    {
                        //stabilim in ce chenar suntem in fct de coloana
                        //un chenar are pt valoarea lui j una din valorile {0,3,6}, deci verificam toate intervalele posibile 
                        if (pos.Item2 < 3)
                        { // ne aflam in coloana 1 de chenare
                          //setam coloana cu 0, treb parcurse coloanele de la 0-2
                            for (c = 0; c <= 2; c++)
                            {
                                if (tabla[l, c] == val)
                                { //nok
                                    exista = true;
                                }
                                else
                                {
                                    exista = false;
                                }
                            }

                        }
                        else if (pos.Item2 > 2 && pos.Item2 < 6)
                        { // ne aflam in coloana 2 de chenare
                          // setam coloana initiala  c= 3
                            c = 3;
                            for (c = 3; c < 6; c++)
                            {
                                if (tabla[l, c] == val)
                                { //nok
                                    exista = true;
                                }
                                else
                                {
                                    exista = false;
                                }
                            }
                        }
                        else if (pos.Item2 > 5 && pos.Item2 < 9)
                        { // ne aflam in coloana 3 de chenare
                          // setam c=6
                            for (c = 6; c < 9; c++)
                            {
                                if (tabla[l, c] == val)
                                { //nok
                                    exista = true;
                                }
                                else
                                {
                                    exista = false;
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("Ceva a mers rau la randurile de sus a tabelului"); //modifica linia de cod!!!
                        }
                    }
                }
                else
                { // margina de jos
                  //in acest caz merg de jos in sus cu 3 linii 
                  //iar coloanele le verific dupa aceeasi regula
                    int l, c;
                    l = pos.Item1;
                    for (l = pos.Item1; l >= pos.Item1 - 2; l--)
                    {
                        //pt c , vdem in ce chenar suntem
                        if (pos.Item2 < 3)
                        { //coloana de chenare 1, initializam cooana c=0

                            for (c = 0; c <= 2; c++)
                            {
                                if (tabla[l, c] == val)
                                { //nok
                                    exista = true;
                                }
                                else
                                {
                                    exista = false;
                                }
                            }
                        }
                        else if (pos.Item2 > 2 && pos.Item2 < 6)
                        {// setul 2 de coloane de chenare
                            for (c = 3; c <= 5; c++)
                            {
                                if (tabla[l, c] == val)
                                { //nok
                                    exista = true;
                                }
                                else
                                {
                                    exista = false;
                                }
                            }
                        }
                        else if (pos.Item2 > 5 && pos.Item2 < 9)
                        { // setul 3 de coloane de chenare
                            for (c = 6; c < 9; c++)
                            {
                                if (tabla[l, c] == val)
                                { //nok
                                    exista = true;
                                }
                                else
                                {
                                    exista = false;
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("Ceva nu e ok la verificarea marginilor de jos a tabelului");
                        }
                    }

                }
            }

            return exista;

        }
        // metoda care verifa toate conditiile jocului
        public bool ValidareFinala(Tuple<int, int> pos, int val)
        {
            bool validare1, validare2, validare3;
            validare1 = validare2 = validare3 = true;
            bool exista = true;
            validare1 = validareLinie(pos, val);
            validare2 = validareColoana(pos, val);
            validare3 = validareChenar(pos, val);
            if (validare1 == false && validare2 == false && validare3 == false)
            { //ok
                exista = false;
            }
            else
            {//nok
                exista = true;
            }
            return exista;
        }

        public Nod Simulation(Nod cap)
        { //parametru este celula ce urmeaza sa fie populata
          //indexarea tabla de joc tabla[0,0] - matrice
            List<Nod> head = cap.child_list;
            bool valid = false;
            int val;
            foreach (Nod x in head)
            {
                val = x.tabla[x.pozitie.Item1, x.pozitie.Item2];
                valid = ValidareFinala(x.pozitie, val);
                if (valid)
                {
                    Console.WriteLine("Simulation OK");
                    //return x;
                }
                else
                    x.tabla[x.pozitie.Item1, x.pozitie.Item2] = 0;

            }
            return cap;

        }
    }
}

