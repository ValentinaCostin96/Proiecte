<?php
session_start();
include "fisier_conexiune_db.php";
$stare=$_POST['stare'];
$id=$_POST['id_masa'];

//$result1=oci_parse($conn,"insert into mese values(NULL,:stare,:numar)");
$result1=oci_parse($conn,"BEGIN PACK_MESE.UPD_MESE(:id,:stare); end;");
oci_bind_by_name($result1, ':stare', $stare);
oci_bind_by_name($result1, ':id', $id);
oci_execute($result1);
echo $result1;
echo 'am ajuns aici';
//header('location:mese.php');
oci_free_statement($result1);
oci_close($conn);

?>