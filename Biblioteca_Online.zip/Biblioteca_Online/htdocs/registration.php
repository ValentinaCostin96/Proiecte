<?php
session_start();
#header('location:login.php');

$con = mysqli_connect('localhost','root','');

mysqli_select_db($con,'userregistration');

$name=$_POST['user'];
$pass=$_POST['password'];

$s = " select * from users where name = '$name'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if( mysqli_num_rows($result) == 1)
{
	/*header('location:home.php');*/
	echo "Username-ul deja exista";
	header('location:nu.php');
}
else
{
	$reg= "insert into users (name,password) values ('$name','$pass')";
	echo 'Registration successful';
	mysqli_query($con,$reg);
	echo 'Registration successful';
	header('location:da.php');
}
?>