	<div class="line-hor"></div>	
			<div class="box">
						<div class="inner">
							<h3>Despre <span>Noi</span></h3>
							<p class="p1 ; detalii2">Noi suntem echipa <b>Podium Shop</b> și facem orice ne stă în putință să vă bucurați de cele mai calitative produse la cel mai bun pret.</p>
							<p class="p1 ; detalii2">Echipa noastră a fost infiintata la sfarsitul anului <strong>2018</strong> inceputul anului <strong>2019</strong>.</p>
							<p class="p1 ; detalii2">Proiectul nostru a luat naștere din dorința și necesitatea de a face un proiect care să cuprindă materia 
							de la disciplina <q>TEHNOLOGII INTERNET</q> </p>
							<p class="p1; detalii2">Noi credem că acest site este util, deoarece veți găsi produsele dumneavoastră preferate fară să pierdeți timp să cautați în magazinele locale</p>
							<p class="p1; detalii2">Produsele noastre vor ajunge la dumneavoastră în cel mai scurt timp posibil</p>
						</div>
				
			</div>
			
			<div class="box2">
			<p><b>Administratorul paginii poate fi contactal la adresa:</b><a href="https://www.facebook.com/costin.valentina.9"> Valentina Costîn </a ></p> </p>
			
		
			
			
			</div>
		</div>
	</body>
</html>