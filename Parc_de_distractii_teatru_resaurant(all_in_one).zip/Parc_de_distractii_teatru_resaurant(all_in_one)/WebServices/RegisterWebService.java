package servicii;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import database.DBManager;
import userspackage.ro.User;

import java.util.ArrayList;
import java.util.Collections;

@Path("register")
public class RegisterWebService {
	//ObjectMapper objectMapper = new ObjectMapper();
	Connection conn;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public boolean register(User user) {
		DBManager db = new DBManager();
		String usr_name=user.getUsername();
		String pass=user.getPassword();
		int id=checkRegister(usr_name, pass);
		if(id!=-1)
		{
			try(Statement st=db.conn.createStatement())
			{
				
				String sql="INSERT INTO UTILIZATOR (ID_CLIENT, USERNAME, PAROLA) VALUES ("+id+",'"+usr_name+"','"+pass+"')";
				System.out.println(sql);
				st.executeQuery(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
		else
			return false;
	}
	
	public int checkRegister(String usr_name, String pass)
	{
		int id=0;
		DBManager db = new DBManager();
		ArrayList<Integer> ids=new ArrayList<Integer>();
		try(Statement st=db.conn.createStatement())
		{
			String query="SELECT ID_CLIENT,USERNAME FROM UTILIZATOR";
			ResultSet rs = st.executeQuery(query);
			while(rs.next()){
				String dbName=rs.getString("USERNAME");
				int dbID=Integer.parseInt(rs.getString("ID_CLIENT"));
				if(usr_name.equals(dbName))
					return -1;
				else
					ids.add(dbID);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(ids.size()!=0)
		{
			id=ids.get(0);
			for(int i=0; i<ids.size(); i++)
			{
				if(ids.get(i)>id)
					id=ids.get(i);
			}
			id++;
		}
		return id;
	}
}
