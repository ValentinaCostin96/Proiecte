<?php 
$num = 12; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
</head>
<body>
<table>
<?php
    echo "<tr>";
    echo "<th>&nbsp;</th>";
    for($col=1;$col<=12;$col++):
        echo "<th>$col</th>";
    endfor;
    echo "</tr>";
    for($row=1, $col=1;$row<=12;$row++):
        echo "<tr>";
        if($col ==1):
            echo "<th>$row</th>";
        endif;
        while($col<=12):
            $res = $row*$col;
            echo "<td>$res</td>";
            $col++;
        endwhile;
        echo "</tr>";
        $col=1;
    endfor;
?>
</table>
</body>
</html>