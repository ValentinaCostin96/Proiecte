<?php session_start();?>
<section>
<?php
		$id = 13; 
		?>
<?php
		if (!isset($_SESSION['user']))
		{	
			echo "<form id='FormaLogare' action = 'login.php' method = 'post'>
			<center><h2>Logare:</h2></center><br/>
			Nume: <input type = 'text' name='user'/><br/><br/>
			Parola: <input type = 'password' name = 'password'/><br/><br/>
			<input class='MenuElement' id='FormaLogareButon' type = 'submit' value = 'Logare'/>
			</form>";
			if (isset($_SESSION['eroare']))
			{
				echo"<center><h2>".$_SESSION['eroare']."</h2></center>";				
			}
		}
		else
		{
			echo "<div style='width:20%; float:left'><h2 id='MesajBunVenit'>Bun Venit, ".$_SESSION['user']."</h2>";
			echo "<form  action='logout.php'>
			<input class='MenuElement' type = 'submit' value='Delogare'/>
			</form><br/>
			<form >
			
			</form><br/>
			<form action='cumpara.php' method='get'>
			<input type = 'hidden' name='id' value = '".$id."'>
			<input class='MenuElement' type = 'submit' value='Cumpara produsul' style='width:280px'/>
			</form>
			</div>";
			echo "<form action = 'cos.php'>
			<input  class= 'Cos' type = 'submit' value = 'Cosul meu'/>
			</form>";
		}
		?>
        <center><h1 class='NumeProduse'>Mocasini de dama imblaniti AB8162-ROSU </h1></center>
		<br/><br/>
		<div class="container">
			<div class="Poze">
				<img  class="BigPhotos" src="./femei/papuci/f7.jpg" style="width:25%">
			</div>
			
			
		</div>	
	
		<div class="Specificatii">
			<center><h1 id="Specificatii">Specificatii:</h1></center>
			<?php
				$produse = file_get_contents("./res/produse.txt");
				$array = json_decode($produse, true);
				$specs = array_keys($array[$id]);
				$values = array_values($array[$id]);
				for ($x = 0; $x < count($array[$id]); $x++)
				{
					echo "<center>".$specs[$x].":".$values[$x]."</center>";
					echo "<br/><br/>";
				}
			?>
		</div>
</section>