<?php
session_start();
include "fisier_conexiune_db.php";
$id=$_POST['id_produs'];
/*echo $name."<br/>";*/
$pret=$_POST['pret_produs'];
/*echo $pass."<br/>";*/
$cantitate=$_POST['cantitate_produs'];

//$result=oci_parse($conn,"update stoc set pret_produs=:pret, cantitate_produs=:cantitate where id_produs=:id and :pret>=0 and :cantitate>=0");
$result=oci_parse($conn,"BEGIN PACK_STOC.UPD_STOC(:id,:pret,:cantitate); end;");
oci_bind_by_name($result, ':id', $id);
oci_bind_by_name($result, ':pret', $pret);
oci_bind_by_name($result, ':cantitate', $cantitate);
oci_execute($result);
echo 'am ajuns aici';
header('location:stoc.php');
oci_free_statement($result);
oci_close($conn);

?>