<?php
session_start();
#header('location:add_book.php');

$con = mysqli_connect('localhost','root','');

mysqli_select_db($con,'userregistration');

$titlu=$_POST['borrow_title'];

$s = " select stoc from book where title = '$titlu'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

#de aici incepe totul
$v=time();
$v2=date("d-m-y",$v1);
$v3=getDate();
$v4=strtotime("+ 14 days 0 month 0 years");
$v5=date("d-m-y",$v4);

if( $result == 0 )
{
    echo "Cartea deja e data";
    
}
else
{
    $reg= "insert into borrow (title) values ('$titlu')";
    mysqli_query($con,$reg);
    $reg2 = "update book set stoc=stoc-1 where title='$titlu';";
    mysqli_query($con,$reg2);
    $reg3 = " update borrow set  untilD='$v5' title='$titlu';";
    mysqli_query($con,$reg3);
	/*echo 'You add a book';*/
	header('location:my_books.php');
}

?>