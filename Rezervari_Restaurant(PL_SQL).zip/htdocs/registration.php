<?php
session_start();
include "fisier_conexiune_db.php";
$name=$_POST['user'];
/*echo $name."<br/>";*/
$pass=$_POST['password'];
/*echo $pass."<br/>";*/
$tip=$_POST['tipR'];




$result=oci_parse($conn,"insert into utilizator values(NULL,:name,:pass,:tip)");
oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':pass', $pass);
oci_bind_by_name($result, ':tip', $tip);
oci_execute($result);
echo 'am ajuns aici';
header('location:login.php');
oci_free_statement($result);
oci_close($conn);

#header('location:login.php');
/* $con = mysqli_connect('localhost','root','');

mysqli_select_db($con,'userregistration');

$name=$_POST['user'];
$pass=$_POST['password'];
$tipR=$_POST['tipReg'];

$s = " select * from users where name = '$name'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if( mysqli_num_rows($result) == 1)
{
	header('location:home.php');
	echo "Username-ul deja exista";
	header('location:nu.php');
}
else
{
	$reg= "insert into users (NUME_USER,PASS_USER,TIP_USER) values ('$name','$pass', '$tipR')";
	echo 'Registration successful';
	mysqli_query($con,$reg);
	echo 'Registration successful';
	header('location:da.php');
}
*/



?>