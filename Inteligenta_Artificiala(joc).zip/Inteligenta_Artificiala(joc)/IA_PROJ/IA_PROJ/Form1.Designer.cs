﻿namespace IA_PROJ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.table1 = new System.Windows.Forms.TableLayoutPanel();
            this.b133 = new System.Windows.Forms.Button();
            this.b132 = new System.Windows.Forms.Button();
            this.b131 = new System.Windows.Forms.Button();
            this.b123 = new System.Windows.Forms.Button();
            this.b122 = new System.Windows.Forms.Button();
            this.b121 = new System.Windows.Forms.Button();
            this.b113 = new System.Windows.Forms.Button();
            this.b112 = new System.Windows.Forms.Button();
            this.b111 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.b233 = new System.Windows.Forms.Button();
            this.b232 = new System.Windows.Forms.Button();
            this.b231 = new System.Windows.Forms.Button();
            this.b223 = new System.Windows.Forms.Button();
            this.b222 = new System.Windows.Forms.Button();
            this.b221 = new System.Windows.Forms.Button();
            this.b213 = new System.Windows.Forms.Button();
            this.b212 = new System.Windows.Forms.Button();
            this.b211 = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.b333 = new System.Windows.Forms.Button();
            this.b332 = new System.Windows.Forms.Button();
            this.b331 = new System.Windows.Forms.Button();
            this.b323 = new System.Windows.Forms.Button();
            this.b322 = new System.Windows.Forms.Button();
            this.b321 = new System.Windows.Forms.Button();
            this.b313 = new System.Windows.Forms.Button();
            this.b312 = new System.Windows.Forms.Button();
            this.b311 = new System.Windows.Forms.Button();
            this.table6 = new System.Windows.Forms.TableLayoutPanel();
            this.b633 = new System.Windows.Forms.Button();
            this.b632 = new System.Windows.Forms.Button();
            this.b631 = new System.Windows.Forms.Button();
            this.b623 = new System.Windows.Forms.Button();
            this.b622 = new System.Windows.Forms.Button();
            this.b621 = new System.Windows.Forms.Button();
            this.b613 = new System.Windows.Forms.Button();
            this.b612 = new System.Windows.Forms.Button();
            this.b611 = new System.Windows.Forms.Button();
            this.table5 = new System.Windows.Forms.TableLayoutPanel();
            this.b533 = new System.Windows.Forms.Button();
            this.b532 = new System.Windows.Forms.Button();
            this.b531 = new System.Windows.Forms.Button();
            this.b523 = new System.Windows.Forms.Button();
            this.b522 = new System.Windows.Forms.Button();
            this.b521 = new System.Windows.Forms.Button();
            this.b513 = new System.Windows.Forms.Button();
            this.b512 = new System.Windows.Forms.Button();
            this.b511 = new System.Windows.Forms.Button();
            this.table4 = new System.Windows.Forms.TableLayoutPanel();
            this.b433 = new System.Windows.Forms.Button();
            this.b432 = new System.Windows.Forms.Button();
            this.b431 = new System.Windows.Forms.Button();
            this.b423 = new System.Windows.Forms.Button();
            this.b422 = new System.Windows.Forms.Button();
            this.b421 = new System.Windows.Forms.Button();
            this.b413 = new System.Windows.Forms.Button();
            this.b412 = new System.Windows.Forms.Button();
            this.b411 = new System.Windows.Forms.Button();
            this.table9 = new System.Windows.Forms.TableLayoutPanel();
            this.b933 = new System.Windows.Forms.Button();
            this.b932 = new System.Windows.Forms.Button();
            this.b931 = new System.Windows.Forms.Button();
            this.b923 = new System.Windows.Forms.Button();
            this.b922 = new System.Windows.Forms.Button();
            this.b921 = new System.Windows.Forms.Button();
            this.b913 = new System.Windows.Forms.Button();
            this.b912 = new System.Windows.Forms.Button();
            this.b911 = new System.Windows.Forms.Button();
            this.table8 = new System.Windows.Forms.TableLayoutPanel();
            this.b833 = new System.Windows.Forms.Button();
            this.b832 = new System.Windows.Forms.Button();
            this.b831 = new System.Windows.Forms.Button();
            this.b823 = new System.Windows.Forms.Button();
            this.b822 = new System.Windows.Forms.Button();
            this.b821 = new System.Windows.Forms.Button();
            this.b813 = new System.Windows.Forms.Button();
            this.b812 = new System.Windows.Forms.Button();
            this.b811 = new System.Windows.Forms.Button();
            this.table7 = new System.Windows.Forms.TableLayoutPanel();
            this.b733 = new System.Windows.Forms.Button();
            this.b732 = new System.Windows.Forms.Button();
            this.b731 = new System.Windows.Forms.Button();
            this.b723 = new System.Windows.Forms.Button();
            this.b722 = new System.Windows.Forms.Button();
            this.b721 = new System.Windows.Forms.Button();
            this.b713 = new System.Windows.Forms.Button();
            this.b712 = new System.Windows.Forms.Button();
            this.b711 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.table1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.table6.SuspendLayout();
            this.table5.SuspendLayout();
            this.table4.SuspendLayout();
            this.table9.SuspendLayout();
            this.table8.SuspendLayout();
            this.table7.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(926, 120);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "NEW GAME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(926, 214);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "START";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // table1
            // 
            this.table1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.table1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table1.ColumnCount = 3;
            this.table1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.table1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.table1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.table1.Controls.Add(this.b133, 2, 2);
            this.table1.Controls.Add(this.b132, 1, 2);
            this.table1.Controls.Add(this.b131, 0, 2);
            this.table1.Controls.Add(this.b123, 2, 1);
            this.table1.Controls.Add(this.b122, 1, 1);
            this.table1.Controls.Add(this.b121, 0, 1);
            this.table1.Controls.Add(this.b113, 2, 0);
            this.table1.Controls.Add(this.b112, 1, 0);
            this.table1.Controls.Add(this.b111, 0, 0);
            this.table1.Location = new System.Drawing.Point(302, 44);
            this.table1.Name = "table1";
            this.table1.RowCount = 3;
            this.table1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.table1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.table1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.table1.Size = new System.Drawing.Size(190, 116);
            this.table1.TabIndex = 5;
            // 
            // b133
            // 
            this.b133.Location = new System.Drawing.Point(121, 86);
            this.b133.Name = "b133";
            this.b133.Size = new System.Drawing.Size(49, 25);
            this.b133.TabIndex = 28;
            this.b133.UseVisualStyleBackColor = true;
            // 
            // b132
            // 
            this.b132.Location = new System.Drawing.Point(62, 86);
            this.b132.Name = "b132";
            this.b132.Size = new System.Drawing.Size(49, 25);
            this.b132.TabIndex = 27;
            this.b132.UseVisualStyleBackColor = true;
            // 
            // b131
            // 
            this.b131.Location = new System.Drawing.Point(5, 86);
            this.b131.Name = "b131";
            this.b131.Size = new System.Drawing.Size(49, 25);
            this.b131.TabIndex = 26;
            this.b131.UseVisualStyleBackColor = true;
            // 
            // b123
            // 
            this.b123.Location = new System.Drawing.Point(121, 48);
            this.b123.Name = "b123";
            this.b123.Size = new System.Drawing.Size(49, 30);
            this.b123.TabIndex = 25;
            this.b123.UseVisualStyleBackColor = true;
            // 
            // b122
            // 
            this.b122.Location = new System.Drawing.Point(62, 48);
            this.b122.Name = "b122";
            this.b122.Size = new System.Drawing.Size(49, 30);
            this.b122.TabIndex = 24;
            this.b122.UseVisualStyleBackColor = true;
            // 
            // b121
            // 
            this.b121.Location = new System.Drawing.Point(5, 48);
            this.b121.Name = "b121";
            this.b121.Size = new System.Drawing.Size(49, 30);
            this.b121.TabIndex = 23;
            this.b121.UseVisualStyleBackColor = true;
            // 
            // b113
            // 
            this.b113.Location = new System.Drawing.Point(121, 5);
            this.b113.Name = "b113";
            this.b113.Size = new System.Drawing.Size(49, 35);
            this.b113.TabIndex = 22;
            this.b113.UseVisualStyleBackColor = true;
            // 
            // b112
            // 
            this.b112.Location = new System.Drawing.Point(62, 5);
            this.b112.Name = "b112";
            this.b112.Size = new System.Drawing.Size(49, 35);
            this.b112.TabIndex = 21;
            this.b112.UseVisualStyleBackColor = true;
            // 
            // b111
            // 
            this.b111.Location = new System.Drawing.Point(5, 5);
            this.b111.Name = "b111";
            this.b111.Size = new System.Drawing.Size(49, 35);
            this.b111.TabIndex = 20;
            this.b111.UseVisualStyleBackColor = true;
            this.b111.Click += new System.EventHandler(this.b111_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel1.Controls.Add(this.b233, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.b232, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.b231, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.b223, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.b222, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.b221, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.b213, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.b212, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.b211, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(498, 44);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(190, 116);
            this.tableLayoutPanel1.TabIndex = 20;
            // 
            // b233
            // 
            this.b233.Location = new System.Drawing.Point(121, 86);
            this.b233.Name = "b233";
            this.b233.Size = new System.Drawing.Size(49, 25);
            this.b233.TabIndex = 28;
            this.b233.UseVisualStyleBackColor = true;
            // 
            // b232
            // 
            this.b232.Location = new System.Drawing.Point(62, 86);
            this.b232.Name = "b232";
            this.b232.Size = new System.Drawing.Size(49, 25);
            this.b232.TabIndex = 27;
            this.b232.UseVisualStyleBackColor = true;
            // 
            // b231
            // 
            this.b231.Location = new System.Drawing.Point(5, 86);
            this.b231.Name = "b231";
            this.b231.Size = new System.Drawing.Size(49, 25);
            this.b231.TabIndex = 26;
            this.b231.UseVisualStyleBackColor = true;
            // 
            // b223
            // 
            this.b223.Location = new System.Drawing.Point(121, 48);
            this.b223.Name = "b223";
            this.b223.Size = new System.Drawing.Size(49, 30);
            this.b223.TabIndex = 25;
            this.b223.UseVisualStyleBackColor = true;
            // 
            // b222
            // 
            this.b222.Location = new System.Drawing.Point(62, 48);
            this.b222.Name = "b222";
            this.b222.Size = new System.Drawing.Size(49, 30);
            this.b222.TabIndex = 24;
            this.b222.UseVisualStyleBackColor = true;
            // 
            // b221
            // 
            this.b221.Location = new System.Drawing.Point(5, 48);
            this.b221.Name = "b221";
            this.b221.Size = new System.Drawing.Size(49, 30);
            this.b221.TabIndex = 23;
            this.b221.UseVisualStyleBackColor = true;
            // 
            // b213
            // 
            this.b213.Location = new System.Drawing.Point(121, 5);
            this.b213.Name = "b213";
            this.b213.Size = new System.Drawing.Size(49, 35);
            this.b213.TabIndex = 22;
            this.b213.UseVisualStyleBackColor = true;
            // 
            // b212
            // 
            this.b212.Location = new System.Drawing.Point(62, 5);
            this.b212.Name = "b212";
            this.b212.Size = new System.Drawing.Size(49, 35);
            this.b212.TabIndex = 21;
            this.b212.UseVisualStyleBackColor = true;
            // 
            // b211
            // 
            this.b211.Location = new System.Drawing.Point(5, 5);
            this.b211.Name = "b211";
            this.b211.Size = new System.Drawing.Size(49, 35);
            this.b211.TabIndex = 20;
            this.b211.UseVisualStyleBackColor = true;
            this.b211.Click += new System.EventHandler(this.b211_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel2.Controls.Add(this.b333, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.b332, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.b331, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.b323, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.b322, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.b321, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.b313, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.b312, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.b311, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(694, 44);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(183, 116);
            this.tableLayoutPanel2.TabIndex = 21;
            // 
            // b333
            // 
            this.b333.Location = new System.Drawing.Point(114, 86);
            this.b333.Name = "b333";
            this.b333.Size = new System.Drawing.Size(49, 25);
            this.b333.TabIndex = 28;
            this.b333.UseVisualStyleBackColor = true;
            // 
            // b332
            // 
            this.b332.Location = new System.Drawing.Point(59, 86);
            this.b332.Name = "b332";
            this.b332.Size = new System.Drawing.Size(47, 25);
            this.b332.TabIndex = 27;
            this.b332.UseVisualStyleBackColor = true;
            // 
            // b331
            // 
            this.b331.Location = new System.Drawing.Point(5, 86);
            this.b331.Name = "b331";
            this.b331.Size = new System.Drawing.Size(46, 25);
            this.b331.TabIndex = 26;
            this.b331.UseVisualStyleBackColor = true;
            // 
            // b323
            // 
            this.b323.Location = new System.Drawing.Point(114, 48);
            this.b323.Name = "b323";
            this.b323.Size = new System.Drawing.Size(49, 30);
            this.b323.TabIndex = 25;
            this.b323.UseVisualStyleBackColor = true;
            // 
            // b322
            // 
            this.b322.Location = new System.Drawing.Point(59, 48);
            this.b322.Name = "b322";
            this.b322.Size = new System.Drawing.Size(47, 30);
            this.b322.TabIndex = 24;
            this.b322.UseVisualStyleBackColor = true;
            // 
            // b321
            // 
            this.b321.Location = new System.Drawing.Point(5, 48);
            this.b321.Name = "b321";
            this.b321.Size = new System.Drawing.Size(46, 30);
            this.b321.TabIndex = 23;
            this.b321.UseVisualStyleBackColor = true;
            // 
            // b313
            // 
            this.b313.Location = new System.Drawing.Point(114, 5);
            this.b313.Name = "b313";
            this.b313.Size = new System.Drawing.Size(49, 35);
            this.b313.TabIndex = 22;
            this.b313.UseVisualStyleBackColor = true;
            // 
            // b312
            // 
            this.b312.Location = new System.Drawing.Point(59, 5);
            this.b312.Name = "b312";
            this.b312.Size = new System.Drawing.Size(47, 35);
            this.b312.TabIndex = 21;
            this.b312.UseVisualStyleBackColor = true;
            // 
            // b311
            // 
            this.b311.Location = new System.Drawing.Point(5, 5);
            this.b311.Name = "b311";
            this.b311.Size = new System.Drawing.Size(46, 35);
            this.b311.TabIndex = 20;
            this.b311.UseVisualStyleBackColor = true;
            // 
            // table6
            // 
            this.table6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.table6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table6.ColumnCount = 3;
            this.table6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.table6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.table6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.table6.Controls.Add(this.b633, 2, 2);
            this.table6.Controls.Add(this.b632, 1, 2);
            this.table6.Controls.Add(this.b631, 0, 2);
            this.table6.Controls.Add(this.b623, 2, 1);
            this.table6.Controls.Add(this.b622, 1, 1);
            this.table6.Controls.Add(this.b621, 0, 1);
            this.table6.Controls.Add(this.b613, 2, 0);
            this.table6.Controls.Add(this.b612, 1, 0);
            this.table6.Controls.Add(this.b611, 0, 0);
            this.table6.Location = new System.Drawing.Point(694, 166);
            this.table6.Name = "table6";
            this.table6.RowCount = 3;
            this.table6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.table6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.table6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.table6.Size = new System.Drawing.Size(183, 116);
            this.table6.TabIndex = 24;
            // 
            // b633
            // 
            this.b633.Location = new System.Drawing.Point(114, 86);
            this.b633.Name = "b633";
            this.b633.Size = new System.Drawing.Size(49, 25);
            this.b633.TabIndex = 28;
            this.b633.UseVisualStyleBackColor = true;
            // 
            // b632
            // 
            this.b632.Location = new System.Drawing.Point(59, 86);
            this.b632.Name = "b632";
            this.b632.Size = new System.Drawing.Size(47, 25);
            this.b632.TabIndex = 27;
            this.b632.UseVisualStyleBackColor = true;
            // 
            // b631
            // 
            this.b631.Location = new System.Drawing.Point(5, 86);
            this.b631.Name = "b631";
            this.b631.Size = new System.Drawing.Size(46, 25);
            this.b631.TabIndex = 26;
            this.b631.UseVisualStyleBackColor = true;
            // 
            // b623
            // 
            this.b623.Location = new System.Drawing.Point(114, 48);
            this.b623.Name = "b623";
            this.b623.Size = new System.Drawing.Size(49, 30);
            this.b623.TabIndex = 25;
            this.b623.UseVisualStyleBackColor = true;
            // 
            // b622
            // 
            this.b622.Location = new System.Drawing.Point(59, 48);
            this.b622.Name = "b622";
            this.b622.Size = new System.Drawing.Size(47, 30);
            this.b622.TabIndex = 24;
            this.b622.UseVisualStyleBackColor = true;
            // 
            // b621
            // 
            this.b621.Location = new System.Drawing.Point(5, 48);
            this.b621.Name = "b621";
            this.b621.Size = new System.Drawing.Size(46, 30);
            this.b621.TabIndex = 23;
            this.b621.UseVisualStyleBackColor = true;
            // 
            // b613
            // 
            this.b613.Location = new System.Drawing.Point(114, 5);
            this.b613.Name = "b613";
            this.b613.Size = new System.Drawing.Size(49, 35);
            this.b613.TabIndex = 22;
            this.b613.UseVisualStyleBackColor = true;
            // 
            // b612
            // 
            this.b612.Location = new System.Drawing.Point(59, 5);
            this.b612.Name = "b612";
            this.b612.Size = new System.Drawing.Size(47, 35);
            this.b612.TabIndex = 21;
            this.b612.UseVisualStyleBackColor = true;
            // 
            // b611
            // 
            this.b611.Location = new System.Drawing.Point(5, 5);
            this.b611.Name = "b611";
            this.b611.Size = new System.Drawing.Size(46, 35);
            this.b611.TabIndex = 20;
            this.b611.UseVisualStyleBackColor = true;
            // 
            // table5
            // 
            this.table5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.table5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table5.ColumnCount = 3;
            this.table5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.table5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.table5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.table5.Controls.Add(this.b533, 2, 2);
            this.table5.Controls.Add(this.b532, 1, 2);
            this.table5.Controls.Add(this.b531, 0, 2);
            this.table5.Controls.Add(this.b523, 2, 1);
            this.table5.Controls.Add(this.b522, 1, 1);
            this.table5.Controls.Add(this.b521, 0, 1);
            this.table5.Controls.Add(this.b513, 2, 0);
            this.table5.Controls.Add(this.b512, 1, 0);
            this.table5.Controls.Add(this.b511, 0, 0);
            this.table5.Location = new System.Drawing.Point(498, 166);
            this.table5.Name = "table5";
            this.table5.RowCount = 3;
            this.table5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.table5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.table5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.table5.Size = new System.Drawing.Size(190, 116);
            this.table5.TabIndex = 23;
            // 
            // b533
            // 
            this.b533.Location = new System.Drawing.Point(121, 86);
            this.b533.Name = "b533";
            this.b533.Size = new System.Drawing.Size(49, 25);
            this.b533.TabIndex = 28;
            this.b533.UseVisualStyleBackColor = true;
            // 
            // b532
            // 
            this.b532.Location = new System.Drawing.Point(62, 86);
            this.b532.Name = "b532";
            this.b532.Size = new System.Drawing.Size(49, 25);
            this.b532.TabIndex = 27;
            this.b532.UseVisualStyleBackColor = true;
            // 
            // b531
            // 
            this.b531.Location = new System.Drawing.Point(5, 86);
            this.b531.Name = "b531";
            this.b531.Size = new System.Drawing.Size(49, 25);
            this.b531.TabIndex = 26;
            this.b531.UseVisualStyleBackColor = true;
            // 
            // b523
            // 
            this.b523.Location = new System.Drawing.Point(121, 48);
            this.b523.Name = "b523";
            this.b523.Size = new System.Drawing.Size(49, 30);
            this.b523.TabIndex = 25;
            this.b523.UseVisualStyleBackColor = true;
            // 
            // b522
            // 
            this.b522.Location = new System.Drawing.Point(62, 48);
            this.b522.Name = "b522";
            this.b522.Size = new System.Drawing.Size(49, 30);
            this.b522.TabIndex = 24;
            this.b522.UseVisualStyleBackColor = true;
            // 
            // b521
            // 
            this.b521.Location = new System.Drawing.Point(5, 48);
            this.b521.Name = "b521";
            this.b521.Size = new System.Drawing.Size(49, 30);
            this.b521.TabIndex = 23;
            this.b521.UseVisualStyleBackColor = true;
            // 
            // b513
            // 
            this.b513.Location = new System.Drawing.Point(121, 5);
            this.b513.Name = "b513";
            this.b513.Size = new System.Drawing.Size(49, 35);
            this.b513.TabIndex = 22;
            this.b513.UseVisualStyleBackColor = true;
            // 
            // b512
            // 
            this.b512.Location = new System.Drawing.Point(62, 5);
            this.b512.Name = "b512";
            this.b512.Size = new System.Drawing.Size(49, 35);
            this.b512.TabIndex = 21;
            this.b512.UseVisualStyleBackColor = true;
            // 
            // b511
            // 
            this.b511.Location = new System.Drawing.Point(5, 5);
            this.b511.Name = "b511";
            this.b511.Size = new System.Drawing.Size(49, 35);
            this.b511.TabIndex = 20;
            this.b511.UseVisualStyleBackColor = true;
            // 
            // table4
            // 
            this.table4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.table4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table4.ColumnCount = 3;
            this.table4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.table4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.table4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.table4.Controls.Add(this.b433, 2, 2);
            this.table4.Controls.Add(this.b432, 1, 2);
            this.table4.Controls.Add(this.b431, 0, 2);
            this.table4.Controls.Add(this.b423, 2, 1);
            this.table4.Controls.Add(this.b422, 1, 1);
            this.table4.Controls.Add(this.b421, 0, 1);
            this.table4.Controls.Add(this.b413, 2, 0);
            this.table4.Controls.Add(this.b412, 1, 0);
            this.table4.Controls.Add(this.b411, 0, 0);
            this.table4.Location = new System.Drawing.Point(302, 166);
            this.table4.Name = "table4";
            this.table4.RowCount = 3;
            this.table4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.table4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.table4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.table4.Size = new System.Drawing.Size(190, 116);
            this.table4.TabIndex = 22;
            // 
            // b433
            // 
            this.b433.Location = new System.Drawing.Point(121, 86);
            this.b433.Name = "b433";
            this.b433.Size = new System.Drawing.Size(49, 25);
            this.b433.TabIndex = 28;
            this.b433.UseVisualStyleBackColor = true;
            // 
            // b432
            // 
            this.b432.Location = new System.Drawing.Point(62, 86);
            this.b432.Name = "b432";
            this.b432.Size = new System.Drawing.Size(49, 25);
            this.b432.TabIndex = 27;
            this.b432.UseVisualStyleBackColor = true;
            // 
            // b431
            // 
            this.b431.Location = new System.Drawing.Point(5, 86);
            this.b431.Name = "b431";
            this.b431.Size = new System.Drawing.Size(49, 25);
            this.b431.TabIndex = 26;
            this.b431.UseVisualStyleBackColor = true;
            // 
            // b423
            // 
            this.b423.Location = new System.Drawing.Point(121, 48);
            this.b423.Name = "b423";
            this.b423.Size = new System.Drawing.Size(49, 30);
            this.b423.TabIndex = 25;
            this.b423.UseVisualStyleBackColor = true;
            // 
            // b422
            // 
            this.b422.Location = new System.Drawing.Point(62, 48);
            this.b422.Name = "b422";
            this.b422.Size = new System.Drawing.Size(49, 30);
            this.b422.TabIndex = 24;
            this.b422.UseVisualStyleBackColor = true;
            // 
            // b421
            // 
            this.b421.Location = new System.Drawing.Point(5, 48);
            this.b421.Name = "b421";
            this.b421.Size = new System.Drawing.Size(49, 30);
            this.b421.TabIndex = 23;
            this.b421.UseVisualStyleBackColor = true;
            // 
            // b413
            // 
            this.b413.Location = new System.Drawing.Point(121, 5);
            this.b413.Name = "b413";
            this.b413.Size = new System.Drawing.Size(49, 35);
            this.b413.TabIndex = 22;
            this.b413.UseVisualStyleBackColor = true;
            // 
            // b412
            // 
            this.b412.Location = new System.Drawing.Point(62, 5);
            this.b412.Name = "b412";
            this.b412.Size = new System.Drawing.Size(49, 35);
            this.b412.TabIndex = 21;
            this.b412.UseVisualStyleBackColor = true;
            this.b412.Click += new System.EventHandler(this.button55_Click);
            // 
            // b411
            // 
            this.b411.Location = new System.Drawing.Point(5, 5);
            this.b411.Name = "b411";
            this.b411.Size = new System.Drawing.Size(49, 35);
            this.b411.TabIndex = 20;
            this.b411.UseVisualStyleBackColor = true;
            // 
            // table9
            // 
            this.table9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.table9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table9.ColumnCount = 3;
            this.table9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.table9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.table9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.table9.Controls.Add(this.b933, 2, 2);
            this.table9.Controls.Add(this.b932, 1, 2);
            this.table9.Controls.Add(this.b931, 0, 2);
            this.table9.Controls.Add(this.b923, 2, 1);
            this.table9.Controls.Add(this.b922, 1, 1);
            this.table9.Controls.Add(this.b921, 0, 1);
            this.table9.Controls.Add(this.b913, 2, 0);
            this.table9.Controls.Add(this.b912, 1, 0);
            this.table9.Controls.Add(this.b911, 0, 0);
            this.table9.Location = new System.Drawing.Point(694, 288);
            this.table9.Name = "table9";
            this.table9.RowCount = 3;
            this.table9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.table9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.table9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.table9.Size = new System.Drawing.Size(183, 116);
            this.table9.TabIndex = 27;
            // 
            // b933
            // 
            this.b933.Location = new System.Drawing.Point(114, 86);
            this.b933.Name = "b933";
            this.b933.Size = new System.Drawing.Size(49, 25);
            this.b933.TabIndex = 28;
            this.b933.UseVisualStyleBackColor = true;
            // 
            // b932
            // 
            this.b932.Location = new System.Drawing.Point(59, 86);
            this.b932.Name = "b932";
            this.b932.Size = new System.Drawing.Size(47, 25);
            this.b932.TabIndex = 27;
            this.b932.UseVisualStyleBackColor = true;
            // 
            // b931
            // 
            this.b931.Location = new System.Drawing.Point(5, 86);
            this.b931.Name = "b931";
            this.b931.Size = new System.Drawing.Size(46, 25);
            this.b931.TabIndex = 26;
            this.b931.UseVisualStyleBackColor = true;
            // 
            // b923
            // 
            this.b923.Location = new System.Drawing.Point(114, 48);
            this.b923.Name = "b923";
            this.b923.Size = new System.Drawing.Size(49, 30);
            this.b923.TabIndex = 25;
            this.b923.UseVisualStyleBackColor = true;
            // 
            // b922
            // 
            this.b922.Location = new System.Drawing.Point(59, 48);
            this.b922.Name = "b922";
            this.b922.Size = new System.Drawing.Size(47, 30);
            this.b922.TabIndex = 24;
            this.b922.UseVisualStyleBackColor = true;
            // 
            // b921
            // 
            this.b921.Location = new System.Drawing.Point(5, 48);
            this.b921.Name = "b921";
            this.b921.Size = new System.Drawing.Size(46, 30);
            this.b921.TabIndex = 23;
            this.b921.UseVisualStyleBackColor = true;
            // 
            // b913
            // 
            this.b913.Location = new System.Drawing.Point(114, 5);
            this.b913.Name = "b913";
            this.b913.Size = new System.Drawing.Size(49, 35);
            this.b913.TabIndex = 22;
            this.b913.UseVisualStyleBackColor = true;
            // 
            // b912
            // 
            this.b912.Location = new System.Drawing.Point(59, 5);
            this.b912.Name = "b912";
            this.b912.Size = new System.Drawing.Size(47, 35);
            this.b912.TabIndex = 21;
            this.b912.UseVisualStyleBackColor = true;
            // 
            // b911
            // 
            this.b911.Location = new System.Drawing.Point(5, 5);
            this.b911.Name = "b911";
            this.b911.Size = new System.Drawing.Size(46, 35);
            this.b911.TabIndex = 20;
            this.b911.UseVisualStyleBackColor = true;
            // 
            // table8
            // 
            this.table8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.table8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table8.ColumnCount = 3;
            this.table8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.table8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.table8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.table8.Controls.Add(this.b833, 2, 2);
            this.table8.Controls.Add(this.b832, 1, 2);
            this.table8.Controls.Add(this.b831, 0, 2);
            this.table8.Controls.Add(this.b823, 2, 1);
            this.table8.Controls.Add(this.b822, 1, 1);
            this.table8.Controls.Add(this.b821, 0, 1);
            this.table8.Controls.Add(this.b813, 2, 0);
            this.table8.Controls.Add(this.b812, 1, 0);
            this.table8.Controls.Add(this.b811, 0, 0);
            this.table8.Location = new System.Drawing.Point(498, 288);
            this.table8.Name = "table8";
            this.table8.RowCount = 3;
            this.table8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.table8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.table8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.table8.Size = new System.Drawing.Size(190, 116);
            this.table8.TabIndex = 26;
            // 
            // b833
            // 
            this.b833.Location = new System.Drawing.Point(121, 86);
            this.b833.Name = "b833";
            this.b833.Size = new System.Drawing.Size(49, 25);
            this.b833.TabIndex = 28;
            this.b833.UseVisualStyleBackColor = true;
            // 
            // b832
            // 
            this.b832.Location = new System.Drawing.Point(62, 86);
            this.b832.Name = "b832";
            this.b832.Size = new System.Drawing.Size(49, 25);
            this.b832.TabIndex = 27;
            this.b832.UseVisualStyleBackColor = true;
            // 
            // b831
            // 
            this.b831.Location = new System.Drawing.Point(5, 86);
            this.b831.Name = "b831";
            this.b831.Size = new System.Drawing.Size(49, 25);
            this.b831.TabIndex = 26;
            this.b831.UseVisualStyleBackColor = true;
            // 
            // b823
            // 
            this.b823.Location = new System.Drawing.Point(121, 48);
            this.b823.Name = "b823";
            this.b823.Size = new System.Drawing.Size(49, 30);
            this.b823.TabIndex = 25;
            this.b823.UseVisualStyleBackColor = true;
            // 
            // b822
            // 
            this.b822.Location = new System.Drawing.Point(62, 48);
            this.b822.Name = "b822";
            this.b822.Size = new System.Drawing.Size(49, 30);
            this.b822.TabIndex = 24;
            this.b822.UseVisualStyleBackColor = true;
            // 
            // b821
            // 
            this.b821.Location = new System.Drawing.Point(5, 48);
            this.b821.Name = "b821";
            this.b821.Size = new System.Drawing.Size(49, 30);
            this.b821.TabIndex = 23;
            this.b821.UseVisualStyleBackColor = true;
            // 
            // b813
            // 
            this.b813.Location = new System.Drawing.Point(121, 5);
            this.b813.Name = "b813";
            this.b813.Size = new System.Drawing.Size(49, 35);
            this.b813.TabIndex = 22;
            this.b813.UseVisualStyleBackColor = true;
            // 
            // b812
            // 
            this.b812.Location = new System.Drawing.Point(62, 5);
            this.b812.Name = "b812";
            this.b812.Size = new System.Drawing.Size(49, 35);
            this.b812.TabIndex = 21;
            this.b812.UseVisualStyleBackColor = true;
            // 
            // b811
            // 
            this.b811.Location = new System.Drawing.Point(5, 5);
            this.b811.Name = "b811";
            this.b811.Size = new System.Drawing.Size(49, 35);
            this.b811.TabIndex = 20;
            this.b811.UseVisualStyleBackColor = true;
            // 
            // table7
            // 
            this.table7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.table7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table7.ColumnCount = 3;
            this.table7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.26471F));
            this.table7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.73529F));
            this.table7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.table7.Controls.Add(this.b733, 2, 2);
            this.table7.Controls.Add(this.b732, 1, 2);
            this.table7.Controls.Add(this.b731, 0, 2);
            this.table7.Controls.Add(this.b723, 2, 1);
            this.table7.Controls.Add(this.b722, 1, 1);
            this.table7.Controls.Add(this.b721, 0, 1);
            this.table7.Controls.Add(this.b713, 2, 0);
            this.table7.Controls.Add(this.b712, 1, 0);
            this.table7.Controls.Add(this.b711, 0, 0);
            this.table7.Location = new System.Drawing.Point(302, 288);
            this.table7.Name = "table7";
            this.table7.RowCount = 3;
            this.table7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.08642F));
            this.table7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.91358F));
            this.table7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.table7.Size = new System.Drawing.Size(190, 116);
            this.table7.TabIndex = 25;
            // 
            // b733
            // 
            this.b733.Location = new System.Drawing.Point(124, 86);
            this.b733.Name = "b733";
            this.b733.Size = new System.Drawing.Size(49, 25);
            this.b733.TabIndex = 28;
            this.b733.UseVisualStyleBackColor = true;
            // 
            // b732
            // 
            this.b732.Location = new System.Drawing.Point(64, 86);
            this.b732.Name = "b732";
            this.b732.Size = new System.Drawing.Size(49, 25);
            this.b732.TabIndex = 27;
            this.b732.UseVisualStyleBackColor = true;
            // 
            // b731
            // 
            this.b731.Location = new System.Drawing.Point(5, 86);
            this.b731.Name = "b731";
            this.b731.Size = new System.Drawing.Size(49, 25);
            this.b731.TabIndex = 26;
            this.b731.UseVisualStyleBackColor = true;
            // 
            // b723
            // 
            this.b723.Location = new System.Drawing.Point(124, 48);
            this.b723.Name = "b723";
            this.b723.Size = new System.Drawing.Size(49, 30);
            this.b723.TabIndex = 25;
            this.b723.UseVisualStyleBackColor = true;
            // 
            // b722
            // 
            this.b722.Location = new System.Drawing.Point(64, 48);
            this.b722.Name = "b722";
            this.b722.Size = new System.Drawing.Size(49, 30);
            this.b722.TabIndex = 24;
            this.b722.UseVisualStyleBackColor = true;
            // 
            // b721
            // 
            this.b721.Location = new System.Drawing.Point(5, 48);
            this.b721.Name = "b721";
            this.b721.Size = new System.Drawing.Size(49, 30);
            this.b721.TabIndex = 23;
            this.b721.UseVisualStyleBackColor = true;
            // 
            // b713
            // 
            this.b713.Location = new System.Drawing.Point(124, 5);
            this.b713.Name = "b713";
            this.b713.Size = new System.Drawing.Size(49, 35);
            this.b713.TabIndex = 22;
            this.b713.UseVisualStyleBackColor = true;
            // 
            // b712
            // 
            this.b712.Location = new System.Drawing.Point(64, 5);
            this.b712.Name = "b712";
            this.b712.Size = new System.Drawing.Size(49, 35);
            this.b712.TabIndex = 21;
            this.b712.UseVisualStyleBackColor = true;
            // 
            // b711
            // 
            this.b711.Location = new System.Drawing.Point(5, 5);
            this.b711.Name = "b711";
            this.b711.Size = new System.Drawing.Size(49, 35);
            this.b711.TabIndex = 20;
            this.b711.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(926, 166);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 23);
            this.button3.TabIndex = 28;
            this.button3.Text = "RESET";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1127, 511);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.table9);
            this.Controls.Add(this.table8);
            this.Controls.Add(this.table7);
            this.Controls.Add(this.table6);
            this.Controls.Add(this.table5);
            this.Controls.Add(this.table4);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.table1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "SUDOKU IA SOLUTION";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.table1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.table6.ResumeLayout(false);
            this.table5.ResumeLayout(false);
            this.table4.ResumeLayout(false);
            this.table9.ResumeLayout(false);
            this.table8.ResumeLayout(false);
            this.table7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TableLayoutPanel table1;
        private System.Windows.Forms.Button b133;
        private System.Windows.Forms.Button b132;
        private System.Windows.Forms.Button b131;
        private System.Windows.Forms.Button b123;
        private System.Windows.Forms.Button b122;
        private System.Windows.Forms.Button b121;
        private System.Windows.Forms.Button b113;
        private System.Windows.Forms.Button b112;
        private System.Windows.Forms.Button b111;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button b233;
        private System.Windows.Forms.Button b232;
        private System.Windows.Forms.Button b231;
        private System.Windows.Forms.Button b223;
        private System.Windows.Forms.Button b222;
        private System.Windows.Forms.Button b221;
        private System.Windows.Forms.Button b213;
        private System.Windows.Forms.Button b212;
        private System.Windows.Forms.Button b211;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button b333;
        private System.Windows.Forms.Button b332;
        private System.Windows.Forms.Button b331;
        private System.Windows.Forms.Button b323;
        private System.Windows.Forms.Button b322;
        private System.Windows.Forms.Button b321;
        private System.Windows.Forms.Button b313;
        private System.Windows.Forms.Button b312;
        private System.Windows.Forms.Button b311;
        private System.Windows.Forms.TableLayoutPanel table6;
        private System.Windows.Forms.Button b633;
        private System.Windows.Forms.Button b632;
        private System.Windows.Forms.Button b631;
        private System.Windows.Forms.Button b623;
        private System.Windows.Forms.Button b622;
        private System.Windows.Forms.Button b621;
        private System.Windows.Forms.Button b613;
        private System.Windows.Forms.Button b612;
        private System.Windows.Forms.Button b611;
        private System.Windows.Forms.TableLayoutPanel table5;
        private System.Windows.Forms.Button b533;
        private System.Windows.Forms.Button b532;
        private System.Windows.Forms.Button b531;
        private System.Windows.Forms.Button b523;
        private System.Windows.Forms.Button b522;
        private System.Windows.Forms.Button b521;
        private System.Windows.Forms.Button b513;
        private System.Windows.Forms.Button b512;
        private System.Windows.Forms.Button b511;
        private System.Windows.Forms.TableLayoutPanel table4;
        private System.Windows.Forms.Button b433;
        private System.Windows.Forms.Button b432;
        private System.Windows.Forms.Button b431;
        private System.Windows.Forms.Button b423;
        private System.Windows.Forms.Button b422;
        private System.Windows.Forms.Button b421;
        private System.Windows.Forms.Button b413;
        private System.Windows.Forms.Button b412;
        private System.Windows.Forms.Button b411;
        private System.Windows.Forms.TableLayoutPanel table9;
        private System.Windows.Forms.Button b933;
        private System.Windows.Forms.Button b932;
        private System.Windows.Forms.Button b931;
        private System.Windows.Forms.Button b923;
        private System.Windows.Forms.Button b922;
        private System.Windows.Forms.Button b921;
        private System.Windows.Forms.Button b913;
        private System.Windows.Forms.Button b912;
        private System.Windows.Forms.Button b911;
        private System.Windows.Forms.TableLayoutPanel table8;
        private System.Windows.Forms.Button b833;
        private System.Windows.Forms.Button b832;
        private System.Windows.Forms.Button b831;
        private System.Windows.Forms.Button b823;
        private System.Windows.Forms.Button b822;
        private System.Windows.Forms.Button b821;
        private System.Windows.Forms.Button b813;
        private System.Windows.Forms.Button b812;
        private System.Windows.Forms.Button b811;
        private System.Windows.Forms.TableLayoutPanel table7;
        private System.Windows.Forms.Button b733;
        private System.Windows.Forms.Button b732;
        private System.Windows.Forms.Button b731;
        private System.Windows.Forms.Button b723;
        private System.Windows.Forms.Button b722;
        private System.Windows.Forms.Button b721;
        private System.Windows.Forms.Button b713;
        private System.Windows.Forms.Button b712;
        private System.Windows.Forms.Button b711;
        private System.Windows.Forms.Button button3;
    }
}

