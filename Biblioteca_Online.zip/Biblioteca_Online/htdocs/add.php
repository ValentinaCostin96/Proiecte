<?php
session_start();
#header('location:add_book.php');

$con = mysqli_connect('localhost','root','');

mysqli_select_db($con,'userregistration');

$titlu=$_POST['book_title'];
$ath_first=$_POST['fautor'];
$ath_last=$_POST['lautor'];

$s = " select * from book where title = '$titlu'";

$s2 = " select * from author where fname='$ath_first' && lname='$ath_last' ";

$result1 = mysqli_query($con,$s);

$result2 = mysqli_query($con,$s2);


$num = mysqli_num_rows($result);

$num2 = mysqli_num_rows($result2);


if(($num || mysqli_num_rows($result) == 1) && ($num2 || mysqli_num_rows($result2)))
{
    echo "Cartea deja exista. Ii vom face o copie";
    
}
else
{
    $reg= "insert into book (title) values ('$titlu')";
    mysqli_query($con,$reg);
    $reg2= "insert into author (fname,lname) values ('$ath_first','$ath_last')";
	mysqli_query($con,$reg2);
	/*echo 'You add a book';*/
	header('location:all_books.php');
}

?>