package servicii;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import database.DBManager;
import userspackage.ro.User;

@Path("login")
public class LoginWebService {
	
	Connection conn;
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public boolean  Login(User user) {
		boolean result=false;
		DBManager db=new DBManager();
		try(Statement st=conn.createStatement())
		{
			
			List<String> usr_pass=new ArrayList<String>();
			String sql="SELECT USERNAME, PASSWORD FROM UTILIZATOR WHERE USERNAME='"+user.getUsername()+"' AND PASSWORD='"+user.getPassword()+"'";
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				String dbName=rs.getString("USERNAME");
				String dbPass=rs.getString("PASSWORD");
				if(dbName.equals(user.getUsername()) && dbPass.equals(user.getPassword()))
					result=true;
			}
			st.close();
			return result;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
}
