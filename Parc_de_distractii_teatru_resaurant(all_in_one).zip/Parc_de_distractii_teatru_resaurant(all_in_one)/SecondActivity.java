package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private Button ViewPark;
    private Button BuyTickets;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        ViewPark = (Button)findViewById(R.id.btnPark);
        BuyTickets = (Button)findViewById(R.id.btnTicket);


        ViewPark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                park_function();
            }
        });

        BuyTickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tickets_function();
            }
        });

    }
    private void park_function() {
        Intent intent2 = new Intent(SecondActivity.this,GalleryActivity.class);
        startActivity(intent2);
    }

    private void tickets_function(){
        Intent intent3 = new Intent(SecondActivity.this,FourActivity.class);
        startActivity(intent3);

    }
}
