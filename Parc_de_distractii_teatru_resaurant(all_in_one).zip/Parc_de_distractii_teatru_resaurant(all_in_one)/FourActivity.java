package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class FourActivity extends AppCompatActivity {

    public TextView MesajTickets_info;
    public Button BackTicketsS4;
    public Button BuyTickets;
    public EditText input_noTickets;
    private TextView NoTicketsbuyed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_four);

        MesajTickets_info = (TextView)findViewById(R.id.tv_buytickets_info);
        BackTicketsS4 = (Button)findViewById(R.id.btnBackS4);
        BuyTickets = (Button)findViewById(R.id.btn_buy_tickets) ;
        input_noTickets = (EditText)findViewById(R.id.et_input_notickets);
        NoTicketsbuyed = (TextView)findViewById(R.id.tvTicket2);

        BackTicketsS4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Back_S4_function();
            }
        });
        NoTicketsbuyed.setText("No of tickets already buyed: "+ toString().valueOf("0"));

        BuyTickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BuyTickets_function();
            }
        });
    }
    public void Back_S4_function(){
        Intent intent4 = new Intent(FourActivity.this,SecondActivity.class);
        startActivity(intent4);
    }
    public void BuyTickets_function(){
        NoTicketsbuyed.setText("No of tickets already buyed: "+ toString().valueOf(input_noTickets.getText()));
    }
}
