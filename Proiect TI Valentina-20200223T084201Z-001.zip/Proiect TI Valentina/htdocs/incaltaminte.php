<?php
		if (!isset($_SESSION['user']))
		{	
			echo "<form id='FormaLogare' action = 'login.php' method = 'post'>
			<center><h2>Logare:</h2></center><br/>
			Nume: <input type = 'text' name='user'/><br/><br/>
			Parola: <input type = 'password' name = 'password'/><br/><br/>
			<input class='MenuElement' id='FormaLogareButon' type = 'submit' value = 'Logare'/>
			</form>";
			if (isset($_SESSION['eroare']))
			{
				echo"<center><h2>".$_SESSION['eroare']."</h2></center>";				
			}
		}
		else
		{
			echo "<div id ='FormaLogare'><h2 id='MesajBunVenit'>Bun Venit, ".$_SESSION['user']."</h2>";
			echo "<form  action='logout.php'>
			<input class='MenuElement' type = 'submit' value='Delogare'/>
			</form><br/>";
			echo "<form >
			</form></div>";
			echo "<form action = 'cos.php'>
			<input  class= 'Cos' type = 'submit' value = 'Cosul meu'/>
			</form>";
		}
		?>
	<div id = "Column">
			<ul id="content">	
            <li><a  href="PapuciF2.php"> <img src="./femei/papuci/f2.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Pantofi cu toc Vilovela Bej </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="PapuciF4.php"> <img src="./femei/papuci/f4.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Pantofi stiletto Unity Rosii </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="PapuciF1.php"> <img src="./femei/papuci/f1.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Pantofi Tropio Aurii </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
			</ul>
		</div>
		
	

        <div id = "Column">
			<ul id="content">
            <li><a  href="PapuciF3.php"> <img src="./femei/papuci/f3.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Pantofi stiletto Tess Bej </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="PapuciF5.php"> <img src="./femei/papuci/f5.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Pantofi Oxford Piedra Camel </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				
			</ul>
		</div>

    

        <div id = "Column">
			<ul id="content">
            <li><a  href="PapuciF8.php"> <img src="./femei/papuci/f8.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Espadrile dama comode 1426-2GALBEN </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="PapuciF7.php"> <img src="./femei/papuci/f7.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Mocasini de dama imblaniti AB8162-ROSU </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
			</ul>
		</div>
<!-- pentru imaginea de flip-flop -->
<div class="josright">
    <div class="flip-box">
    <div class="flip-box-inner">
        <div class="flip-box-front">
        <img class="sticky1" src="./imagini/jos.jpg" alt="Podium Shop" style="width:300px;height:200px">
        </div>
        <div class="flip-box-back">
        <h2>Podium Shop</h2>
        <p>Ați gasit ceea ce căutați?</p>
        </div>
    </div>
    </div>
</div>