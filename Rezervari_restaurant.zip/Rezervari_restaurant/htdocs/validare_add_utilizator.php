<?php
session_start();
include "fisier_conexiune_db.php";
$name=$_POST['user'];
/*echo $name."<br/>";*/
$pass=$_POST['password'];
/*echo $pass."<br/>";*/
$tip=$_POST['tip_user'];

//$result=oci_parse($conn,"insert into utilizator values(NULL,:name,:pass,'admin')");
$result=oci_parse($conn,"BEGIN
PACK_USERS.ADD_USERS(:name,:pass,:tip); end;
");
oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':pass', $pass);
oci_bind_by_name($result, ':tip', $tip);
oci_execute($result);
echo 'am ajuns aici';
//header('location:admin.php');
oci_free_statement($result);
oci_close($conn);

?>