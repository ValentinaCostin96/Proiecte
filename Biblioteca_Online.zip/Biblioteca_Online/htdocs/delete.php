<?php
session_start();
#header('location:delete_book.php');

$con = mysqli_connect('localhost','root','');

mysqli_select_db($con,'userregistration');

$titlu=$_POST['book_title_delete'];
$ath_first=$_POST['fautor_delete'];
$ath_last=$_POST['lautor_delete'];

$s = " select * from book where title = '$titlu' ;";


$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

/*
if( $num || mysqli_num_rows($result) == 1 )
{
    echo "Cartea nu exista";
    
}
else
{
    */
   
    /*$reg = " delete from author where lname='$ath_last' && fname = '$sth_first'
    && title='$titlu'";
    mysqli_query($con,$reg);*/
    $contor=" count (*) where title= '$titlu' ;";
    if($contor != 0){
        $reg= " delete from book where title= '$titlu' ;";
        mysqli_query($con,$reg);
        echo 'You delete a book and the author';
    }else{
        echo 'Cartea nu exista in biblioteca.';
    }
  
	/*header('location:all_books.php');*/
#}

?>
  <a  href="login.php" onclick="loadDoc('delete_book.php')"  style="text-collor:red ">go back</a>