<?php
		if (!isset($_SESSION['user']))
		{	
			echo "<form id='FormaLogare' action = 'login.php' method = 'post'>
			<center><h2>Logare:</h2></center><br/>
			Nume: <input type = 'text' name='user'/><br/><br/>
			Parola: <input type = 'password' name = 'password'/><br/><br/>
			<input class='MenuElement' id='FormaLogareButon' type = 'submit' value = 'Logare'/>
			</form>";
			if (isset($_SESSION['eroare']))
			{
				echo"<center><h2>".$_SESSION['eroare']."</h2></center>";				
			}
		}
		else
		{
			echo "<div id ='FormaLogare'><h2 id='MesajBunVenit'>Bun Venit, ".$_SESSION['user']."</h2>";
			echo "<form  action='logout.php'>
			<input class='MenuElement' type = 'submit' value='Delogare'/>
			</form><br/>";
			echo "<form>
			</form></div>";
			echo "<form action = 'cos.php'>
			<input  class= 'Cos' type = 'submit' value = 'Cosul meu'/>
			</form>";
		}
		?>
		<div id = "Column">
			<ul id="content">				
            <li><a  href="Lantisor.php"> <img src="./femei/accesorii/f4.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Colier dama cu piatra verde CP-17103 </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="Cioker.php"> <img src="./femei/accesorii/f3.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Colier choker CJ40-42-NEGRU</p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
			
				
			</ul>
		</div>
		



        <div id = "Column">
			<ul id="content">
            <li><a  href="Ceas2.php"> <img src="./femei/accesorii/f7.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Ceas Quartz </p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="Ceas3.php"> <img src="./femei/accesorii/f5.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Ceas de dama Fossil Georgia Mini ES4340</p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
			</ul>
		</div>



        <div id = "Column">
			<ul id="content">
            <li><a  href="Ochelari.php"> <img src="./femei/accesorii/f9.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Ochelari de soare polarizati</p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
				<li><a  href="Ceas1.php"> <img src="./femei/accesorii/f6.jpg" style="width:70%">
					<p class="DenumiriPaginaPrincipala" >Ceas de dama Fossil Georgia Mini ES4340</p></a>
				</li>
				<br /><br /><br /><br /><br /><br />
			</ul>
		</div>
		<!-- pentru imaginea de flip-flop -->
<div class="josright">
    <div class="flip-box">
    <div class="flip-box-inner">
        <div class="flip-box-front">
        <img class="sticky1" src="./imagini/jos.jpg" alt="Podium Shop" style="width:300px;height:200px">
        </div>
        <div class="flip-box-back">
        <h2>Podium Shop</h2>
        <p>Ați gasit ceea ce căutați?</p>
        </div>
    </div>
    </div>
</div>