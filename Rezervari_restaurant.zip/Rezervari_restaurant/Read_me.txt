O idee mai buna este ca aceasta aplicatie sa fie facuta pe mobile, deoarece clientii ar putea
sa dea o comanda de la masa fara a mai fi nevoie sa cheme chelnerul.
Iar chelnerul ar primi notificari in timp real de la masa care face requestul.