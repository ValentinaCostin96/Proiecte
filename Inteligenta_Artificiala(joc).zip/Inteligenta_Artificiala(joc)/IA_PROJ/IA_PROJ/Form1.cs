﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace IA_PROJ
{
    public partial class Form1 : Form
    {
        public int[,] tabla = new int[9, 9];


        public Form1()
        {
            InitializeComponent();
        }

        
            
            

        
        
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

         
        

        private void button1_Click(object sender, EventArgs e)
        {
            int x; //acesta va fi un nr random care ne va genera o varianta de sudoku

            /*GOLIRE BUTOANE*/
            b111.Text = "";
            b112.Text = "";
            b113.Text = "";
            b121.Text = "";
            b122.Text = "";
            b123.Text = "";
            b131.Text = "";
            b132.Text = "";
            b133.Text = "";

            b211.Text = "";
            b212.Text = "";
            b213.Text = "";
            b221.Text = "";
            b222.Text = "";
            b223.Text = "";
            b231.Text = "";
            b232.Text = "";
            b233.Text = "";

            b311.Text = "";
            b312.Text = "";
            b313.Text = "";
            b321.Text = "";
            b322.Text = "";
            b323.Text = "";
            b331.Text = "";
            b332.Text = "";
            b333.Text = "";

            b411.Text = "";
            b412.Text = "";
            b413.Text = "";
            b421.Text = "";
            b422.Text = "";
            b423.Text = "";
            b431.Text = "";
            b432.Text = "";
            b433.Text = "";

            b511.Text = "";
            b512.Text = "";
            b513.Text = "";
            b521.Text = "";
            b522.Text = "";
            b523.Text = "";
            b531.Text = "";
            b532.Text = "";
            b533.Text = "";

            b611.Text = "";
            b612.Text = "";
            b613.Text = "";
            b621.Text = "";
            b622.Text = "";
            b623.Text = "";
            b631.Text = "";
            b632.Text = "";
            b633.Text = "";

            b711.Text = "";
            b712.Text = "";
            b713.Text = "";
            b721.Text = "";
            b722.Text = "";
            b723.Text = "";
            b731.Text = "";
            b732.Text = "";
            b733.Text = "";

            b811.Text = "";
            b812.Text = "";
            b813.Text = "";
            b821.Text = "";
            b822.Text = "";
            b823.Text = "";
            b831.Text = "";
            b832.Text = "";
            b833.Text = "";

            b911.Text = "";
            b912.Text = "";
            b913.Text = "";
            b921.Text = "";
            b922.Text = "";
            b923.Text = "";
            b931.Text = "";
            b932.Text = "";
            b933.Text = "";

            Random rand = new Random();
            // x = rand.Next(1, 6);

            x = 1;
            if (x == 1)
            {
                string[] v = new string[38] {"9", "4", "1","7","2","9","3","1","3","8","9","3",
                                              "6","1","4","8","4","5","9","6","8","1","7","5","4","6","3","9",
                                              "7","1","6","3","6","2","8","2","3","4"};
                b111.Text = v[0];
                tabla[0, 0] = Int32.Parse(v[0]);
                b113.Text = v[1];
                tabla[0, 2] = Int32.Parse(v[1]);
                b121.Text = v[2];
                tabla[1, 0] = Int32.Parse(v[2]);
                b211.Text = v[3];
                tabla[0, 3] = Int32.Parse(v[3]);
                b213.Text = v[4];
                tabla[0, 5] = Int32.Parse(v[4]);
                b223.Text = v[5];
                tabla[1, 5] = Int32.Parse(v[5]);
                b233.Text = v[6];
                tabla[2, 5] = Int32.Parse(v[6]);
                b311.Text = v[7];
                tabla[0, 6] = Int32.Parse(v[7]);
                b312.Text = v[8];
                tabla[0, 7] = Int32.Parse(v[8]);
                b313.Text = v[9];
                tabla[0, 8] = Int32.Parse(v[9]);
                b331.Text = v[10];
                tabla[2, 6] = Int32.Parse(v[10]);
                b411.Text = v[11];
                tabla[3, 0] = Int32.Parse(v[11]);
                b412.Text = v[12];
                tabla[3, 1] = Int32.Parse(v[12]);
                b413.Text = v[13];
                tabla[3, 2] = Int32.Parse(v[13]);
                b422.Text = v[14];
                tabla[4, 1] = Int32.Parse(v[14]);
                b423.Text = v[15];
                tabla[4, 2] = Int32.Parse(v[15]);
                b511.Text = v[16];
                tabla[3, 3] = Int32.Parse(v[15]);
                b513.Text = v[17];
                tabla[3, 5] = Int32.Parse(v[17]);
                b521.Text = v[18];
                tabla[4, 3] = Int32.Parse(v[18]);
                b523.Text = v[19];
                tabla[4, 5] = Int32.Parse(v[19]);
                b531.Text = v[20];
                tabla[5, 5] = Int32.Parse(v[20]);
                b533.Text = v[21];
                tabla[4,6] = Int32.Parse(v[21]);
                b621.Text = v[22];
                tabla[4,8] = Int32.Parse(v[22]);
                b623.Text = v[23];
                tabla[5,6] = Int32.Parse(v[23]);
                b631.Text = v[24];
                tabla[5,7] = Int32.Parse(v[24]);
                b632.Text = v[25];
                tabla[5, 8] = Int32.Parse(v[25]);
                b633.Text = v[26];
                tabla[6,2] = Int32.Parse(v[26]);
                b713.Text = v[27];
                tabla[8,0] = Int32.Parse(v[27]);
                b731.Text = v[28];
                tabla[8,1] = Int32.Parse(v[28]);
                b732.Text = v[29];
                tabla[8, 2] = Int32.Parse(v[29]);
                b733.Text = v[30];
                tabla[8, 3] = Int32.Parse(v[30]);
                b811.Text = v[31];
                tabla[6,3] = Int32.Parse(v[31]);
                b821.Text = v[32];
                tabla[7,3] = Int32.Parse(v[32]);
                b831.Text = v[33];
                tabla[8,3] = Int32.Parse(v[33]);
                b833.Text = v[34];
                tabla[8, 5] = Int32.Parse(v[34]);
                b923.Text = v[35];
                tabla[7,8] = Int32.Parse(v[35]);
                b931.Text = v[36];
                tabla[8,6] = Int32.Parse(v[36]);
                b933.Text = v[37];
                tabla[8, 8] = Int32.Parse(v[37]);
            }
            else if (x == 2)
            {
                string[] v = new string[38] {"5","4","2","7","8","1","7","5","3","6","8","7","3","9","6","2","1","3","4","1",
                    "1","4","5","2","6","7","6","9","5","2","5","7","4","2","5","7","4","3"};

                b111.Text = v[0];
                b121.Text = v[1];
                b122.Text = v[2];
                b132.Text = v[3];
                b133.Text = v[4];
                b212.Text = v[5];
                b213.Text = v[6];
                b221.Text = v[7];
                b223.Text = v[8];
                b312.Text = v[9];
                b321.Text = v[10];
                b323.Text = v[11];
                b331.Text = v[12];
                b411.Text = v[13];
                b412.Text = v[14];
                b413.Text = v[15];
                b422.Text = v[16];
                b431.Text = v[17];
                b511.Text = v[18];
                b533.Text = v[19];
                b613.Text = v[20];
                b622.Text = v[21];
                b631.Text = v[22];
                b632.Text = v[23];
                b633.Text = v[24];
                b713.Text = v[25];
                b721.Text = v[26];
                b723.Text = v[27];
                b732.Text = v[28];
                b821.Text = v[29];
                b823.Text = v[30];
                b831.Text = v[31];
                b832.Text = v[32];
                b911.Text = v[33];
                b912.Text = v[34];
                b922.Text = v[35];
                b923.Text = v[36];
                b933.Text = v[37];
            }
            else if (x == 3)
            {
                //var3 easy 
                string[] v = new string[38] {"6","9","2","2","8","1","5","3","8","4","9"
                ,"7","3","4","2","6","5","9","5","6","4","2","9","5","1","8","7",
                "6","8","2","5","9","4","3","4","5","2","1"};
                b112.Text = v[0];
                b113.Text = v[1];
                b133.Text = v[2];
                b221.Text = v[3];
                b233.Text = v[4];
                b311.Text = v[5];
                b313.Text = v[6];
                b321.Text = v[7];
                b323.Text = v[8];
                b331.Text = v[9];
                b333.Text = v[10];
                b411.Text = v[11];
                b413.Text = v[12];
                b421.Text = v[13];
                b422.Text = v[14];
                b423.Text = v[15];
                b431.Text = v[16];
                b432.Text = v[17];
                b511.Text = v[18];
                b533.Text = v[19];
                b612.Text = v[20];
                b613.Text = v[21];
                b621.Text = v[22];
                b622.Text = v[23];
                b623.Text = v[24];
                b631.Text = v[25];
                b633.Text = v[26];
                b711.Text = v[27];
                b713.Text = v[28];
                b721.Text = v[29];
                b723.Text = v[30];
                b731.Text = v[31];
                b733.Text = v[32];
                b811.Text = v[33];
                b823.Text = v[34];
                b911.Text = v[35];
                b931.Text = v[36];
                b932.Text = v[37];
            }
            else if (x == 4)
            {
                // var 4 medium
                string[] v = new string[30] {"7","9","1","8","7","8","6","9","3","4","2"
                ,"1","3","4","4","5","9","5","8","8","9","5","4","6","3","1","5",
                "9","4","1"};
                b122.Text = v[0];
                b123.Text = v[1];
                b131.Text = v[2];
                b132.Text = v[3];
                b213.Text = v[4];
                b221.Text = v[5];
                b233.Text = v[6];
                b312.Text = v[7];
                b321.Text = v[8];
                b323.Text = v[9];
                b333.Text = v[10];
                b412.Text = v[11];
                b431.Text = v[12];
                b433.Text = v[13];
                b513.Text = v[14];
                b531.Text = v[15];
                b611.Text = v[16];
                b613.Text = v[17];
                b632.Text = v[18];
                b711.Text = v[19];
                b721.Text = v[20];
                b723.Text = v[21];
                b732.Text = v[22];
                b811.Text = v[23];
                b823.Text = v[24];
                b831.Text = v[25];
                b912.Text = v[26];
                b913.Text = v[27];
                b921.Text = v[28];
                b922.Text = v[29];
            }
            else
            {
                //var 5 hard
                string[] v = new string[28] {"6","5","9","5","3","6","8","2","4","4","6"
                ,"7","1","2","9","9","1","6","8","5","1","9","7","6","1","7","2",
                "9"};
                b121.Text = v[0];
                b122.Text = v[1];
                b123.Text = v[2];
                b212.Text = v[3];
                b222.Text = v[4];
                b231.Text = v[5];
                b233.Text = v[6];
                b323.Text = v[7];
                b331.Text = v[8];
                b412.Text = v[9];
                b413.Text = v[10];
                b431.Text = v[11];
                b433.Text = v[12];
                b511.Text = v[13];
                b533.Text = v[14];
                b611.Text = v[15];
                b613.Text = v[16];
                b631.Text = v[17];
                b632.Text = v[18];
                b713.Text = v[19];
                b721.Text = v[20];
                b811.Text = v[21];
                b813.Text = v[22];
                b822.Text = v[23];
                b832.Text = v[24];
                b921.Text = v[25];
                b922.Text = v[26];
                b923.Text = v[27];
            }
            //done :)
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void c133_TextChanged(object sender, EventArgs e)
        {

        }

        private void c112_TextChanged(object sender, EventArgs e)
        {

        }

        private void c122_TextChanged(object sender, EventArgs e)
        {

        }

        private void c132_TextChanged(object sender, EventArgs e)
        {

        }

        private void c121_TextChanged(object sender, EventArgs e)
        {

        }

        private void c131_TextChanged(object sender, EventArgs e)
        {

        }

        private void c411_TextChanged(object sender, EventArgs e)
        {

        }

        private void c412_TextChanged(object sender, EventArgs e)
        {

        }

        private void button55_Click(object sender, EventArgs e)
        {

        }

        private void b111_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //MAKE SURE THAT ALL CELLS ARE EMPTY
            /* string[] v = new string[9] {"11","12","13",
             "21","22","23","31","32","33"};
             for (int i=1; i <= 9; i++) {
                 for (int j=0; j < 9; j++) {
                     var s1 = string.Format("{0}{1}",i,v[j]);
                      Console.WriteLine(s1.ToString());
                      var s2 = string.Concat("b", s1.ToString());
                      MessageBox.Show(s2.ToString());
                 }
             }
             */
            b111.Text = "";
            b112.Text = "";
            b113.Text = "";
            b121.Text = "";
            b122.Text = "";
            b123.Text = "";
            b131.Text = "";
            b132.Text = "";
            b133.Text = "";

            b211.Text = "";
            b212.Text = "";
            b213.Text = "";
            b221.Text = "";
            b222.Text = "";
            b223.Text = "";
            b231.Text = "";
            b232.Text = "";
            b233.Text = "";

            b311.Text = "";
            b312.Text = "";
            b313.Text = "";
            b321.Text = "";
            b322.Text = "";
            b323.Text = "";
            b331.Text = "";
            b332.Text = "";
            b333.Text = "";

            b411.Text = "";
            b412.Text = "";
            b413.Text = "";
            b421.Text = "";
            b422.Text = "";
            b423.Text = "";
            b431.Text = "";
            b432.Text = "";
            b433.Text = "";

            b511.Text = "";
            b512.Text = "";
            b513.Text = "";
            b521.Text = "";
            b522.Text = "";
            b523.Text = "";
            b531.Text = "";
            b532.Text = "";
            b533.Text = "";

            b611.Text = "";
            b612.Text = "";
            b613.Text = "";
            b621.Text = "";
            b622.Text = "";
            b623.Text = "";
            b631.Text = "";
            b632.Text = "";
            b633.Text = "";

            b711.Text = "";
            b712.Text = "";
            b713.Text = "";
            b721.Text = "";
            b722.Text = "";
            b723.Text = "";
            b731.Text = "";
            b732.Text = "";
            b733.Text = "";

            b811.Text = "";
            b812.Text = "";
            b813.Text = "";
            b821.Text = "";
            b822.Text = "";
            b823.Text = "";
            b831.Text = "";
            b832.Text = "";
            b833.Text = "";

            b911.Text = "";
            b912.Text = "";
            b913.Text = "";
            b921.Text = "";
            b922.Text = "";
            b923.Text = "";
            b931.Text = "";
            b932.Text = "";
            b933.Text = "";

        }

        private void b211_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MCTS a = new MCTS();
            var pos = Tuple.Create(0, 1);
            List<Nod> child_list = new List<Nod>();
            for(int i=0; i<9; i++)
            {
                Nod n = new Nod();
                List<Nod> c_l = new List<Nod>();
                n.np = 0;
                n.pozitie = pos;
                n.S = 0;
                n.tabla = tabla;
                n.vi = 0;
                n.ni = 0;
                n.adancime = 1;
                n.nod_parinte = null;
                n.dead_end = false;
                n.child_list = c_l;
                bool val = a.validareLinie(pos, i + 1); //val este mereu false
                if (val)
                    child_list.Add(n);

                
            }
            Nod root = new Nod(0, 1, 0, tabla, child_list, null, pos, 1, false, 0);
           
            
            int depth = 1;
           while (depth != 38)
            {
                Nod node = new Nod();
                node = a.Selection(root);
                node = a.Expansion(node);
                node = a.Simulation(node);
                a.Backpropagation(node);
                depth = node.adancime;
            }
        }
    }
}
