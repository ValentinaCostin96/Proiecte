package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
//import android.util.Log;

//import pt conectarea cu bd;
/*
import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.toolbox.JsonObjectRequest;
//import com.loopj.android.http.*;


import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.client.WebTarget;
*/
public class MainActivity extends AppCompatActivity {


    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = (EditText)findViewById(R.id.etName);
        Password = (EditText)findViewById((R.id.etPassword));
        Info = (TextView)findViewById(R.id.tvInfo);
        Login = (Button)findViewById((R.id.btnLogin));

        Info.setText("No of attempts remaining: 5");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(),Password.getText().toString());
            }
        });

    }


    private void validate(String userName, String userPassword){
        if((userName.equals( "Admin")) && (userPassword.equals("1234"))){
            Intent intent = new Intent(MainActivity.this,SecondActivity.class);
            startActivity(intent);
        }else{
            counter--;
            Info.setText("No of attempts remaining: " + String.valueOf(counter));

            if(counter == 0)
            {
                Login.setEnabled(false);
            }
        }
    }
    /*
    User user = new User(Name.toString(),Password.toString());

    //Log.d("String de intrare", req);
    RequestQueue queue = Volley.newRequestQueue(this);
    String url = "http://192.168.43.94:8081/RestaurantManagement/api/login";
    JsonObjectRequest req = new JsonObjectRequest(Request.Method.POST, url,  null, new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {

        }
    },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }

                ) {
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            Map<String, String> params = new HashMap<>();
            params.put("put", req.toString());
            return params;
        }
    };

*/
   /* StringRequest stringRequest = new StringRequest(Request.Method.PUT, url,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                }
            }

    ) {
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            Map<String, String> params = new HashMap<>();
            params.put("put", req.toString());
            return params;
        }

    };*/


}
