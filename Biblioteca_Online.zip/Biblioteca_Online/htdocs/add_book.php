<?php session_start();?>
<!DOCTYPE html>

<html lang="ro">
<head>
	<title>Biblioteca Valentinei</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/stil.css" />
</head>
<body>
    			
		<div id = "navigation">
          <nav id="Menu">
                <a class="MenuElement" href="home.php" onclick="loadDoc('home.php')">
                    <?php echo $_SESSION['username'];?>
                </a>
				<a class="MenuElement" href = "all_books.php" onclick="loadDoc('all_books.php')">ALL BOOKS</a>
				<a class="MenuElement"  href = "my_books.php" onclick="loadDoc('my_books.php')">MY BOOKS </a>
				<a class="MenuElement" href = "all_users.php" onclick="loadDoc('all_users.php')">ALL USERS</a>
                <a class="MenuElement" href="add_book.php" onclick="loadDoc('add_book.php')" >ADD BOOK</a>
                <a class="MenuElement" href="delete_book.php" onclick="loadDoc('delete_book.php')" >DELETE BOOK</a>
				<a class="MenuElement" href="borrow_book.php" onclick="loadDoc('borrow.php')" >BORROW BOOK</a>
                <a class="MenuElement" href="logIn.php" onclick="loadDoc('logout.php')"  style="float:right">LOG OUT</a>
			</nav>
        </div>
        <br />
        <br />
        <div id="main">
            <b>
                <form action="add.php" method="post">
                <label for="book">Book title</label><br /><br />
                <input type="text" id="book_title" name="book_title"><br /><br />

                <label for="autor">Author first name</label><br /><br />
                <input type="text" class="autor" name="fautor" ><br /><br />

                <label for="autor">Author last name</label><br /><br />
                <input type="text" class="autor" name="lautor" ><br /><br />

                <input type="submit" value="ADD"><br /><br />
                </form>
                </b>

        
        <main>
        <div class="josright" style="background-image:url('img/book.jpg') ; width:200px; height:150px">  
            <img src="img/book.jpg" style="width:200px; height:150px" />     
         </div>
</div>
</body>