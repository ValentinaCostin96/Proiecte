<?php session_start(); ?>
<html>
	<head>
		<title>Podium Shop</title>
		<meta charset="utf-8">		
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "stylesheet" href="/css/style.css">
		<script type="text/javascript" src = "js/script.js"></script>
        <script>
            function openNav() {
	document.getElementById("mySidenav").style.display = "block";
  }
  
  function closeNav() {
	document.getElementById("mySidenav").style.display = "none";
  }
 </script>
	</head>
	
	<body onload="loadDoc('acasa.php')">
	<header id="header"> 
	    <h1><img height="40" width="40" src="./imagini/logo.png" alt="logo podium" text-align="left" />Podium Shop</h1>
	</header>
			<!--Menu bar -->
		<div id = "navigation">
			<nav id="Menu">
				<a class="MenuElement" href="#" onclick="loadDoc('acasa.php')">Acasa</a>
				<a class="MenuElement" href = "#" onclick="loadDoc('imbracaminte.php')">Imbracaminte</a>
				<a class="MenuElement"  href = "#" onclick="loadDoc('incaltaminte.php')">Incaltaminte </a>
				<a class="MenuElement" href = "#" onclick="loadDoc('accesorii.php')">Accesorii</a>
				<a class="MenuElement" href="#" onclick="loadDoc('despre.php')" >Despre</a>
				<a class="MenuElement" href="#" onclick="loadDoc('contact.php')" >Contact</a>
                <a class="MenuElement" href="#" onclick="loadDoc('inregistrare.php')" >Inregistrare</a>
                <a class="MenuElement" href="#" onclick="loadDoc('best.php')" >Best sellers</a>
				<a class="MenuElement" href="#" onclick="openNav()">&#9776; Open tabel cu marimi</a>
			</nav>
		</div>
		<section>


		<article id="continut"></article>




<!-- TABELUL CU MARIMI-->
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#" style="color:blue">GHID DE MARIMI</a>
  <br><br><br>
  <table >
  <tr>
    
    <th colspan="2" style="color:purple">Mărime</th>
	<th style="color:purple">PIEPT</th>
	<th style="color:purple">TALIE</th>
	<th style="color:purple">ȘOLD</th>
  </tr>
  <tr>
    <td>32/34</td>
    <td>XS</td>
    <td>74-81</td>
	<td>60-65</td>
    <td>84-91</td>
  </tr>
  <tr>
    <td>36/38</td>
    <td>S</td>
    <td>82-89</td>
	<td>66-73</td>
    <td>92-98</td>
  </tr>
  <tr>
    <td>40/42</td>
    <td>M</td>
    <td>90-97</td>
	<td>74-81</td>
    <td>99-106</td>
  </tr>
  <tr>
    <td>44/46</td>
    <td>L</td>
    <td>98-107</td>
	<td>82-91</td>
    <td>107-115</td>
  </tr>
   <tr>
    <td>48/50</td>
    <td>XL</td>
    <td>108-119</td>
	<td>92-102</td>
    <td>116-125</td>
  </tr>
</table>
    <br><br><br> <br><br><br>
    <p style="color:purple" ><b>Sperăm ca v-am fost de ajutor!<b></p>
</div>


    </body>
  

</html>