function CumparareNereusita()
{
	alert('Nu aveti fonduri suficiente in portofel');
}

function CumparareReusita()
{
	alert('Tranzactie reusita');
}

function loadDoc(pagina) {
	var xmlhttp;

	if (window.XMLHttpRequest) {
		xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				document.getElementById("continut").innerHTML = xmlhttp.responseText;
	
			}
		}
	}

	xmlhttp.open("GET", pagina, true);
	xmlhttp.send();
}


function formValidation()
{
	var x;
	
	x = document.getElementById('CardNumber').value;	
	
	alert(x);

	
	if (x == "" || isNaN(x) || (x.toString().length != 12) )
	{
		alert("Numar de card invalid");
	}
	

}
/*SCRIPT PT TABELUL CU MARIMI*/
function openNav() {
	document.getElementById("mySidenav").style.display = "block";
  }
  
  function closeNav() {
	document.getElementById("mySidenav").style.display = "none";
 }
 /*pentru ultimul best sellers */

 
 var slideIndex = 1;
showSlides(slideIndex);


function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  if(n>2)
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
 /*pentru contact */
 function validare(){
	var nume=document.forms["contact"]["nume"];
	var email=document.forms["contact"]["mail"];
	var mesaj=document.forms["contact"]["mesaj"];
	nume.style.background = 'Black';
	email.style.background = 'Black';
	mesaj.style.background = 'Black';
	nume.style.color = 'White';
	email.style.color = 'White';
	mesaj.style.color = 'White';
		var error = "";
	    var illegalChars = /\W/; 
	
	    if (nume.value == "" || email.value=="" || mesaj.value=="") {
	        nume.style.background = 'Yellow';
	        email.style.background = 'Yellow';
	        mesaj.style.background = 'Yellow';
	        nume.style.color = 'Black';
			email.style.color = 'Black';
			mesaj.style.color = 'Black';

	        error = "Completați toate câmpurile!\n";
	        document.getElementById("eroareV").innerHTML=error;
	        //alert(error);
	        return false;
	 
	    } else if ((nume.value.length < 5) || (nume.value.length > 15)) {
	        nume.style.background = 'Yellow';
	        nume.style.color = 'Black';
	        error = "Numele trebuie să fie format din minim 5 litere, maxim 15!\n";
	        document.getElementById("eroareV").innerHTML=error;
			//alert(error);
			return false;
	 
	    } else if (illegalChars.test(nume.value)) {
	        nume.style.background = 'Yellow';
	        nume.style.color = 'Black';
	        error = "Numele conține caractere nepermise!\n";
	        document.getElementById("eroareV").innerHTML=error;
			//alert(error);
			return false;
	 
	    }	 
	    else {
	    	//Numele a fost validat
	        nume.style.background = 'Black';
	        nume.style.color = 'White';

	        var atpos = email.value.indexOf("@");
	    	var dotpos = email.value.lastIndexOf(".");
	    	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
	    		email.style.background = 'Yellow';
	    		email.style.color = 'Black';
	    		error="Adresa de email nu este validă!";
	    		document.getElementById("eroareV").innerHTML=error;
	        	//alert(error);
	        	return false;
	    	}
	    	else{
	    		//Adresa a fost validata
	    		email.style.background = 'Black';
	        	email.style.color = 'White';
	    	}
	    }
	    return true;
}

function validare2(){
	var nume=document.forms["confirmare"]["nume"];
	var prenume=document.forms["confirmare"]["prenume"];
	var telefon=document.forms["confirmare"]["telefon"];
	nume.style.background = 'White';
	prenume.style.background = 'White';
	telefon.style.background = 'White';
	nume.style.color = 'Black';
	prenume.style.color = 'Black';
	telefon.style.color = 'Black';

		var error = "";
	    var illegalChars = /\W/; 
	
	    if (nume.value == "" || prenume.value=="" || telefon.value=="") {
	        nume.style.background = 'Yellow';
	        prenume.style.background = 'Yellow';
	        telefon.style.background = 'Yellow';
	        nume.style.color = 'Black';
			prenume.style.color = 'Black';
			telefon.style.color = 'Black';

	        error = "Completați toate câmpurile!\n";
	        document.getElementById("eroareV").innerHTML=error;
	        //alert(error);
	        return false;
	 
	    } else if ((nume.value.length < 5) || (nume.value.length > 15)) {
	        nume.style.background = 'Yellow';
	        nume.style.color = 'Black';
	        error = "Numele trebuie să fie format din minim 5 litere, maxim 15!\n";
			document.getElementById("eroareV").innerHTML=error;
			//alert(error);
			return false;
	 
	    } else if (illegalChars.test(nume.value)) {
	        nume.style.background = 'Yellow';
	        nume.style.color = 'Black';
	        error = "Numele conține caractere nepermise!\n";
			document.getElementById("eroareV").innerHTML=error;
			//alert(error);
			return false;
	 
	    } 
	    else {
	    	//Numele a fost validat
	        nume.style.background = 'White';
	        nume.style.color = 'Black';

	        if ((prenume.value.length < 5) || (prenume.value.length > 15)) {
		        prenume.style.background = 'Yellow';
		        prenume.style.color = 'Black';
		        error = "Prenumele trebuie să fie format din minim 5 litere, maxim 15!\n";
				document.getElementById("eroareV").innerHTML=error;
				//alert(error);
				return false;
		 
		    } else if (illegalChars.test(prenume.value)) {
		        prenume.style.background = 'Yellow';
		        prenume.style.color = 'Black';
		        error = "Prenumele conține caractere nepermise!\n";
				document.getElementById("eroareV").innerHTML=error;
				//alert(error);
				return false;
		 
		    }
		    else{
			    	//Prenumele a fost validat
		        nume.style.background = 'White';
		        nume.style.color = 'Black';

		        var stripped = telefon.value.replace(/[\(\)\.\-\ ]/g, '');
		    	if (isNaN(parseInt(stripped))) {
			        error = "Numărul de telefon conține caractere nepermise! \n";
			        telefon.style.background = 'Yellow';
			        telefon.style.color = 'Black';
			        document.getElementById("eroareV").innerHTML=error;
			       // alert(error);
					return false;
			    } else if (!(stripped.length == 10)) {
			        error = "Numărul de telefon trebuie să conțină 10 cifre!\n";
			        telefon.style.background = 'Yellow';
			        telefon.style.color = 'Black';
			        document.getElementById("eroareV").innerHTML=error;
			        //alert(error);
					return false;
			    }
		    	else{
		    		//Telefonul a fost validata
		    		telefon.style.background = 'White';
		        	telefon.style.color = 'Black';
		    	}
		    }
	        
	    }
	    return true;
	//}
}

// Converteste dintr-un array JAvascript intr-un array PHP
function convert(JsArr){
    var Php = '';
    if (Array.isArray(JsArr)){  
        Php += 'array(';
        for (var i in JsArr){
            Php += '\'' + i + '\' => ' + convert(JsArr[i]);
            if (JsArr[i] != JsArr[Object.keys(JsArr)[Object.keys(JsArr).length-1]]){
                Php += ', ';
            }
        }
        Php += ')';
        return Php;
    }
    else{
        return '\'' + JsArr + '\'';
    }
}
