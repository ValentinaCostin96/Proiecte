
<?php 	
	session_start();		
    echo "Ati cumparat produsul!";
?>
</body>

