<?php
session_start();
include "fisier_conexiune_db.php";
$stare=$_POST['stare'];
echo $stare."<br/>";
$numar=$_POST['numar'];
echo $numar."<br/>";


//$result1=oci_parse($conn,"insert into mese values(NULL,:stare,:numar)");
$result1=oci_parse($conn,"BEGIN
  PACK_MESE.ADD_MESE(:stare,:numar); end;");
oci_bind_by_name($result1, ':stare', $stare);
oci_bind_by_name($result1, ':numar', $numar);
oci_execute($result1);
echo $result1;
echo 'am ajuns aici';
header('location:mese.php');
oci_free_statement($result1);
oci_close($conn);

?>