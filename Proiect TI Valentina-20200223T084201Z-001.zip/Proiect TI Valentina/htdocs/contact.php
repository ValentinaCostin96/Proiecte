<div id="content">
  <div class="line-hor"></div>
  <div class="box">
    <div>
      <div >
        <div class="inner">
          <h3>Date de <span>Contact</span></h3>
          <div class="address">
            <div class="fleft"><span>Zip Code:</span>700259<br />
              <span>Țară:</span>România<br />
              <span>Telefon:</span>0748867712<br />
              <span>Fax:</span>+354 5035619
            </div>
            <div class="extra-wrap">
              <p style="font-size: 30;color:white;margin-bottom: -38px;">Informații utile:</p>
              <p class="detalii"> Vă rugăm să ne trimiteți orice sugeție sau problemă în legătură cu site-ul nostru. Echipa noastră este disponibilă 24/24.</p>
            </div>     
          </div>

          <div class="extra-wrap">
         <p> Alte servicii disponibile:</p>
			  <br/><br/>
		  	<div class="icon">
			  	<a href="https://facebook.com"><img src="media/icon1.png"  width="40px" height="40px"></a>
				  <a href="https://gmail.com"><img src="media/icon2.png" width="40px" height="40px"></a>
				  <a href="https://twitter.com"><img src="media/icon3.png" width="40px" height="40px"></a>
		  	</div>

     </div>
        </div>
      </div>
    </div>
  </div>





<!--scoate daca nu rez 
  <div class="content">
    <div class="box2">
    <div class="movie-contact">
      <div class="content">  
        
        <h3>Formular de <span>Contact</span></h3>
        <form name="contact" action='api/sendInfo.php' onsubmit="return validare()" method='post'>
          <div class="eroareVContact" id="eroareV" ></div>
          <fieldset id="contacts-form">
            <div class="field">
              <label>Nume:</label>
              <input type="text" name="nume" placeholder=" Nume" value=""/>
            </div>
            <div class="field">
              <label>E-mail:</label>
              <input type="emails" name="mail" placeholder=" aa@aa.com"  value=""/>
            </div>
            <div class="field">
              <label>Mesajul dumneavoastră:</label>
              <textarea cols="37" rows="4" name="mesaj"></textarea>
            </div>
          </fieldset>

          <div>  <input class="sendC" type="submit" value="Send Now"><span><span></span></span></div>
        </form>
      </div>
    </div>
    </div>
  </div>
  -->
