<?php
       session_start();
      /* header('location:all_books.php');*/
      $con = mysqli_connect('localhost','root','');
      /* include_once('connection.php'); */
      mysqli_select_db($con,'userregistration');
      $query = " select  title,fromD  from borrow ;" ;  
       $result = mysqli_query($con,$query);

 ?>

<!DOCTYPE html>

<html lang="ro">
<head>
	<title>Biblioteca Valentinei</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/stil.css" />
</head>
<body>
    			
		<div id = "navigation">
                <nav id="Menu">
                                <a class="MenuElement" href="home.php" onclick="loadDoc('home.php')">
                                <?php echo $_SESSION['username'];?>
                                </a>
                               <a class="MenuElement" href = "all_books.php" onclick="loadDoc('all_books.php')">ALL BOOKS</a>
				<a class="MenuElement"  href = "my_books.php" onclick="loadDoc('my_books.php')">MY BOOKS </a>
				<a class="MenuElement" href = "all_users.php" onclick="loadDoc('all_users.php')">ALL USERS</a>
                                <a class="MenuElement" href="add_book.php" onclick="loadDoc('add_book.php')" >ADD BOOK</a>
                                <a class="MenuElement" href="delete_book.php" onclick="loadDoc('delete_book.php')" >DELETE BOOK</a>
                                <a class="MenuElement" href="borrow_book.php" onclick="loadDoc('borrow.php')" >BORROW BOOK</a>
                                <a class="MenuElement" href="logIn.php" onclick="loadDoc('logout.php')"  style="float:right">LOG OUT</a>
			</nav>
        </div>
        <br />
        <br />
        <div id="cartile_mele" style="width:45%; height:500px; border-color:black; margin-left:200px">
                <br />
                <table  >
                      <tr >
                                   <th >Book title</th>
                                   <th >Data imprumutarii</th>
                                  
                      </tr>
                      <?php
                            while($rows =mysqli_fetch_row($result))
                            {
                     ?>
                       <tr >
                                  
                                  <td><?php echo $rows[0]; ?></td>
                                   <td><?php echo $rows[1]; ?></td>
                            
                                     
                        </tr>
                        <?php
                          }
                         ?>
                </table>    
        </div>
</body>

