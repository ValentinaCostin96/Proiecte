package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GalleryActivity extends AppCompatActivity {

    public Button Back_park;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        Back_park = (Button)findViewById(R.id.btn_back_park);

        Back_park.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_park_function();
            }
        });
    }
    public void back_park_function(){
        Intent intent5 = new Intent(GalleryActivity.this,SecondActivity.class);
        startActivity(intent5);
    }
}
