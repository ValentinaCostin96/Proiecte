<?php
session_start();
include "fisier_conexiune_db.php";
//$name=$_POST['user'];

$ora=$_POST['ora_reervare'];

$data=$_POST['data_rezervare'];

//$result=oci_parse($conn,"insert into utilizator values(NULL,:name,:pass,'admin')");
$result=oci_parse($conn,"");
//oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':ora', $ora);
oci_bind_by_name($result, ':data', $data);
oci_execute($result);
echo 'am ajuns aici';
//header('location:admin.php');
oci_free_statement($result);
oci_close($conn);

?>