<?php
session_start();
include "fisier_conexiune_db.php";
$id=$_POST['id_admin'];
/*echo $stare."<br/>";
$nume=$_POST['nume_admin'];
echo $numar."<br/>";*/


//$result1=oci_parse($conn,"delete from utilizator where id_user=:id and nume_user=:nume");
$result1=oci_parse($conn,"begin   PACK_USERS.DEL_USERS(:id);
END;");
oci_bind_by_name($result1, ':id', $id);
//oci_bind_by_name($result1, ':nume', $nume);
oci_execute($result1);
echo $result1;
echo 'am ajuns aici';
header('location:admin.php');
oci_free_statement($result1);
oci_close($conn);

?>