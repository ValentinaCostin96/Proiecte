<?php
	session_start();
 	$produs = $_GET['id'];
	echo $produs;
	if (in_array($produs, $_SESSION['cos']))
	{
		$key = array_search($produs, $_SESSION['cos']);
		unset($_SESSION['cos'][$key]);
	}
	else
	{
		array_push($_SESSION['cos'], $produs);
	}
	header("Location: ".$_SERVER["HTTP_REFERER"]);	
?>