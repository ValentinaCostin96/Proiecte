<?php
session_start();
include "fisier_conexiune_db.php";
$id=$_POST['id_masa'];



//$result1=oci_parse($conn,"delete from mese where id_masa=:id and stare_masa=0");
$result1=oci_parse($conn," begin PACK_MESE.DEL_MESE(:id); END;");
oci_bind_by_name($result1, ':id', $id);
oci_execute($result1);
echo $result1;
echo 'am ajuns aici';
header('location:mese.php');
oci_free_statement($result1);
oci_close($conn);

?>