<?php
session_start();
include "fisier_conexiune_db.php";
$name=$_POST['user'];
/*echo $name."<br/>";*/
$pass=$_POST['password'];
/*echo $pass."<br/>";*/
$tip=$_POST['tip_user'];
$id=$_POST['id_user'];

//$result=oci_parse($conn,"insert into utilizator values(NULL,:name,:pass,'admin')");
$result=oci_parse($conn,"BEGIN
PACK_USERS.UPD_USERS(:id,:name,:pass,:tip); end;
");
oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':pass', $pass);
oci_bind_by_name($result, ':tip', $tip);
oci_bind_by_name($result, ':id', $id);
oci_execute($result);
echo 'am ajuns aici';
if ($tip=='chelner')
{
    header('location:chelneri.php');
}elseif($tip=='admin')
{
    header('location:admin.php');
}
header('location:chelneri.php');
oci_free_statement($result);
oci_close($conn);

?>