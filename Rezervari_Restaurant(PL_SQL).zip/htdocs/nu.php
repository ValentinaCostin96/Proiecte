<html lang="ro">
<head>
	<title>Biblioteca Valentinei</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/stil.css" />
</head>
<body>
    <h1> NU TE-AI INREGISTRAT CU SUCCES! MAI INCEARCA...</h1>
    <a class="MenuElement" href="login.php" onclick="loadDoc('logout.php')"  style="float:right; text-color:red">LOG OUT</a>
</body>