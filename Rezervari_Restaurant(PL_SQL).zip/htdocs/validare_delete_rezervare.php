<?php
session_start();
include "fisier_conexiune_db.php";
$id=$_POST['id_rezervare'];
$ora=$_POST['ora_reervare'];
$data=$_POST['data_rezervare'];


//$result1=oci_parse($conn,"delete from stoc where id_produs=:id");
$result1=oci_parse($conn,"");
oci_bind_by_name($result1, ':id', $id);
oci_bind_by_name($result1, ':ora', $ora);
oci_bind_by_name($result1, ':data', $data);
oci_execute($result1);
echo $result1;
echo 'am ajuns aici';
//header('location:stoc.php');
oci_free_statement($result1);
oci_close($conn);

?>