<?php session_start(); ?>
		<center>
				<form class = "Inregistrare" action="" method = "post">
					Nume utilizator: <input class = "Inregistrare" type = "text" name="user"/><br/><br/>
					Introduceti o parola : <input class = "Inregistrare" type = "password" name = "pass" ><br/><br/>
					Confirmati parola : <input class = "Inregistrare" type = "password" name = "cpass"><br/><br/>
					<input class = "Inregistrare" type = "submit" value = "Inregistrare"/>
				</form>
		</center>
		<?php
		$flag  = 1;
		if (isset($_POST['user']) && isset($_POST['pass']) && isset($_POST['cpass']))
		{
			if ( ($_POST['user'] == ''))
			{
				echo "<center><h1>Nume de utilizator invalid</h1></center>";
			}	
			else if (($_POST['pass'] == '') )
			{
				echo "<center><h1>Parolele nu coincid</h1></center>";
			}
			 else if (isset ($_POST['user']) && isset($_POST['pass']) && isset($_POST['cpass']) && ($_POST['user'] != '') && ($_POST['pass'] != '') && ($_POST['cpass'] != ''))
			{
				{			
					if($_POST['pass'] === $_POST['cpass'])
					{
						if (filesize("./res/users.txt") == 0)
						{
							$NewUser = array(array('Nume' => $_POST['user'], 'Password' => $_POST['pass'],'Portofel'=>0));
							file_put_contents("./res/users.txt", json_encode($NewUser));
							$cos = array();
							$NewBox = array(array('Nume' => $_POST['user'], 'Cos' => $cos));
							file_put_contents("./res/cos.txt", json_encode($NewBox));
						}
						else
						{
							$OldUsers = file_get_contents("./res/users.txt");
							$OldUsersArray = json_decode($OldUsers,true );
							for ($x = 0; $x < count($OldUsersArray); $x++)
							{
								if ($OldUsersArray[$x]['Nume'] == $_POST['user'])
								{
									$flag = 0;
								}
							}
							if ( $flag != 0)						
							{
								file_put_contents("./res/users.txt", "["); 
								for ($y = 0; $y < count($OldUsersArray); $y++)
								{
									if ($y != 0)
									{				
										file_put_contents("./res/users.txt", ",",FILE_APPEND | LOCK_EX );
									}
									$NewUser = array('Nume'=> $OldUsersArray[$y]['Nume'], 'Password' => $OldUsersArray[$y]['Password'], 'Portofel'=>$OldUsersArray[$y]['Portofel']);
									file_put_contents("./res/users.txt",json_encode($NewUser), FILE_APPEND | LOCK_EX );
								}								
									$LastUser  =  array('Nume' => $_POST['user'], 'Password' => $_POST['pass'], 'Portofel'=>0 );
									file_put_contents("./res/users.txt",",", FILE_APPEND | LOCK_EX );
									file_put_contents("./res/users.txt",json_encode($LastUser), FILE_APPEND | LOCK_EX );
									file_put_contents("./res/users.txt","]", FILE_APPEND | LOCK_EX );
									
									$CosActual = file_get_contents("./res/cos.txt");
									$cos = array();	
									$CosNou = array('Nume' => $_POST['user'], 'Cos'=> $cos);
									$NewCos = substr_replace($CosActual, ",".json_encode($CosNou)."]", strlen($CosActual)-1);
									file_put_contents("./res/cos.txt", $NewCos);
								
							}
							else
							{
								echo "<center><h2>Numele de utilizator deja coincide cu a unui alt user</h2></center>";	
							}	
						}
					}
					else
					{
						echo "<center><h2>Parolele nu coincid</h2></center>";
					}
				}
			}
			else
			{
				echo "<center><h2>Date invalide, va rugam reintroduceti datele</h2></center>";
			}
		}
		?>
