﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IA_PROJ
{
    public class Nod
    {
        public double S { get; set; } //valoarea nodului
        public int np { get; set; } //de cate ori a fost vizitat nodul curent
        public int ni { get; set; } //suma vizitelor pe copii
        public int[,] tabla { get; set; } //matricea cu configuratia initiala a jocului [9x9]
        public List<Nod> child_list { get; set; }//lista cu nodurile copii initial generica pentru evitarea erorilor       
        public Nod nod_parinte; //pointer catre nodul parinte al nodului curent
        public Tuple<int, int> pozitie { get; set; } //pozitia in matrice la care se va afce schimbarea
        public int adancime { get; set; } //adancimea nodului curent
        public bool dead_end { get; set; } //false- daca jocul poate continua pe aceasta ramura, true- s-a ajuns la dead end
        public double vi { get; set; } //suma de s de la copii
        public Nod() { }
        public Nod(double S, int np, int ni, int[,] tabla, List<Nod> child_list, Nod nod_parinte, Tuple<int, int> pozitie, int adancime, bool dead_end, double vi)
        {
            this.S = S;
            this.np = np;
            this.ni = ni;
            this.tabla = tabla;
            this.child_list = child_list;
            this.nod_parinte = nod_parinte;
            this.pozitie = pozitie;
            this.adancime = adancime;
            this.dead_end = dead_end;
            this.vi = vi;
        }
        double calculS(Nod n)
        {
            double C = Math.Sqrt(2);
            int D = 5000;
            int valoare_castig = 1;
            int x_b = valoare_castig / n.np;//valoarea jocului = simulari rezultate cu o victorie / nr de simulari
            double a = Math.Log(n.np) / n.ni;
            double b = (n.vi - n.ni * (x_b ^ 2) + D) / n.ni;
            double Suma = x_b + C * Math.Sqrt(a) + Math.Sqrt(b);
            //t(n) = np -> de cate ori a fost vizitat nodul n
            //t(ni) = ni -> de cate ori a fost vizitat copilul
            //x^2 = vi -> suma rezultatelor din copil
            //D = constanta adaugata pentru a se asigura ca nodurile care au fost vizitate mai rar sunt nesigure
            return Suma;
        }

    }
}
